package com.example.storyforge.core

import com.example.storyforge.model.ConversationTurn
import com.example.storyforge.model.DigestLine
import com.example.storyforge.prompt.PromptCard
import com.example.storyforge.prompt.Message

/**
 * Assembles a prompt from structured memory and user input for narration.
 */
object PromptAssembler {

    data class PromptAssemblerInput(
        val promptCard: PromptCard,
        val bufferTurns: List<ConversationTurn>,
        val digestLines: List<DigestLine>,
        val worldState: Map<String, String>,
        val characterState: Map<String, Map<String, String>>,
        val userMessage: String
    )

    data class AssembledPrompt(
        val messages: List<Message>,
        val tokenEstimate: Int
    )

    fun assemble(input: PromptAssemblerInput): AssembledPrompt {
        val messages = mutableListOf<Message>()

        // 1. Narrator persona
        messages += Message(role = "system", content = input.promptCard.prompt.trim())

        // 2. Tag mapping block (e.g. "#mc = MyCharacter")
        val tagLines = extractTagMap(input.characterState)
        if (tagLines.isNotEmpty()) {
            messages += Message("system", "Tag Mapping:\n" + tagLines.joinToString("\n"))
        }

        // 3. Game rules
        if (input.promptCard.gameRules.isNotBlank()) {
            messages += Message("system", "Game Rules:\n" + input.promptCard.gameRules.trim())
        }

        // 4. World and character state
        messages += Message("system", buildStateSummary(input.worldState, input.characterState))

        // 5. Digest lines (summary of prior events)
        if (input.digestLines.isNotEmpty()) {
            messages += Message("system", "Story so far:\n" +
                    input.digestLines.joinToString("\n") { "- ${it.line}" })
        }

        // 6. Last N turns of full text
        input.bufferTurns.forEach { turn ->
            messages += Message(role = "user", content = turn.user)
            messages += Message(role = "assistant", content = turn.narrator)
        }

        // 7. New input
        messages += Message(role = "user", content = input.userMessage.trim())

        return AssembledPrompt(
            messages = messages,
            tokenEstimate = estimateTokens(messages)
        )
    }

    private fun buildStateSummary(
        world: Map<String, String>,
        characters: Map<String, Map<String, String>>
    ): String {
        val sb = StringBuilder()

        if (world.isNotEmpty()) {
            sb.append("World State:\n")
            for ((key, value) in world) {
                sb.append("- $key: $value\n")
            }
        }

        if (characters.isNotEmpty()) {
            sb.append("Characters:\n")
            for ((name, traits) in characters) {
                sb.append("- $name:\n")
                for ((k, v) in traits) {
                    sb.append("  • $k: $v\n")
                }
            }
        }

        return sb.toString().trim()
    }

    private fun extractTagMap(characters: Map<String, Map<String, String>>): List<String> {
        return characters.keys.mapNotNull { name ->
            val tag = name.lowercase().replace(" ", "_")
            if (tag.isNotBlank()) "#$tag = $name" else null
        }
    }

    private fun estimateTokens(messages: List<Message>): Int {
        return messages.sumOf { it.content.length / 4 } // crude estimate
    }
}
