package com.example.storyforge.model

import kotlinx.serialization.json.JsonElement

sealed class DeltaInstruction {
    data class Add(val key: String, val value: JsonElement) : DeltaInstruction()
    data class Assign(val key: String, val value: JsonElement) : DeltaInstruction()
    data class Declare(val key: String, val value: JsonElement) : DeltaInstruction()
    data class Delete(val key: String) : DeltaInstruction()

    fun toLogValue(): Any = when (this) {
        is Add -> mapOf("+" to value)
        is Assign -> mapOf("@" to value)
        is Declare -> mapOf("!" to value)
        is Delete -> "-"
    }
}
