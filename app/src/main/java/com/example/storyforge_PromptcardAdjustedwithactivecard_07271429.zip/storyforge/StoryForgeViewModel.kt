package com.example.storyforge

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.storyforge.core.NarrationParser
import com.example.storyforge.core.Narrator
import com.example.storyforge.model.GameState
import com.example.storyforge.model.GameStateSlotStorage
import com.example.storyforge.model.GameStateStorage
import com.example.storyforge.prompt.PromptCard
import com.example.storyforge.prompt.PromptCardStorage
import com.example.storyforge.settings.Settings
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import android.content.Context
import android.util.Log
import com.example.storyforge.ui.screens.flattenJsonObject
import kotlinx.serialization.json.*

data class Turn(val action: String, val narration: String)

class StoryForgeViewModel(
    private var aiNarrator: Narrator,
    private val narratorFactory: () -> Narrator,
    private val _settings: Settings,
    private val promptCardStorage: PromptCardStorage,
    val appContext: Context
) : ViewModel() {

    private val _gameState = MutableStateFlow(GameStateStorage.load(appContext))
    private val _promptCards = MutableStateFlow<List<PromptCard>>(emptyList())
    private val _turns = MutableStateFlow<List<Turn>>(emptyList())
    private val _errorMessage = MutableStateFlow<String?>(null)
    private val _isProcessing = MutableStateFlow(false)
    private val _worldChangeMessage = MutableStateFlow<String?>(null)
    private val _pinnedKeys = MutableStateFlow<Set<String>>(emptySet())
    private val _activePromptCard = MutableStateFlow<PromptCard?>(null)

    val activePromptCard: StateFlow<PromptCard?> = _activePromptCard.asStateFlow()
    val gameState: StateFlow<GameState> = _gameState.asStateFlow()
    val promptCards: StateFlow<List<PromptCard>> = _promptCards.asStateFlow()
    val turns: StateFlow<List<Turn>> = _turns.asStateFlow()
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()
    val isProcessing: StateFlow<Boolean> = _isProcessing.asStateFlow()
    val worldChangeMessage: StateFlow<String?> = _worldChangeMessage.asStateFlow()
    val pinnedKeys: StateFlow<Set<String>> = _pinnedKeys.asStateFlow()
    val settings: Settings
        get() = _settings

    init {
        _promptCards.value = promptCardStorage.loadDefaultsIfEmpty()
        aiNarrator = narratorFactory()

        // Debug the pinned keys flow
        viewModelScope.launch {
            _pinnedKeys.collect { keys ->
                Log.d("PIN_DEBUG", "Pinned keys updated: $keys")
            }
        }
    }

    fun setActivePromptCard(card: PromptCard) {
        _activePromptCard.value = card
    }

    fun setNarrator(newNarrator: Narrator) {
        aiNarrator = newNarrator
    }


    fun addPromptCard(card: PromptCard) {
        _promptCards.update { current ->
            val updated = current + card
            promptCardStorage.saveCards(updated)
            updated
        }
    }

    fun deletePromptCard(id: String) {
        _promptCards.update { current ->
            val updated = current.filterNot { it.id == id }
            promptCardStorage.saveCards(updated)
            updated
        }
    }

    fun processAction(action: String) {
        if (action.isBlank()) {
            _errorMessage.value = "Action cannot be empty"
            return
        }

        _turns.value += Turn(action = action, narration = "")

        viewModelScope.launch {
            _isProcessing.value = true
            _errorMessage.value = null

            val narrationResult = aiNarrator.generate(action, _gameState.value)

            narrationResult.fold(
                onSuccess = { (narration, parsedDeltas) ->
                    _gameState.value = _gameState.value.apply {
                        this.narration = narration
                        applyDeltas(parsedDeltas)
                    }

                    NarrationParser.logDeltas(parsedDeltas)
                    GameStateStorage.save(appContext, _gameState.value)

                    val current = _turns.value
                    if (current.isNotEmpty()) {
                        _turns.value = current.dropLast(1) + Turn(action = action, narration = narration)
                    }

                    val changeKeys = parsedDeltas.keys.joinToString(", ")
                    if (changeKeys.isNotBlank()) {
                        _worldChangeMessage.value = "World updated: $changeKeys"
                        launch {
                            delay(3000)
                            _worldChangeMessage.value = null
                        }
                    }
                },
                onFailure = { error ->
                    _errorMessage.value = when (error) {
                        is IllegalStateException -> "Server error: ${error.message}"
                        else -> "Action failed: ${error.localizedMessage}"
                    }
                }
            )

            _isProcessing.value = false
        }
    }

    fun clearError() {
        _errorMessage.value = null
    }

    fun saveToSlot(promptCardName: String) {
        GameStateSlotStorage.saveSlot(appContext, _gameState.value, promptCardName)
    }

    fun resetSession(newState: GameState = GameState()) {
        _gameState.value = newState
        _turns.value = emptyList()
        _errorMessage.value = null
        _isProcessing.value = false
    }

    fun togglePin(prefixKey: String) {
        Log.d("PIN_DEBUG", "Toggling pin for: $prefixKey")

        val flatWorld = flattenJsonObject(_gameState.value.worldState)
        val affectedKeys = flatWorld.keys.filter { it.startsWith(prefixKey) }

        if (affectedKeys.isEmpty()) {
            Log.w("PIN_DEBUG", "No keys matched for $prefixKey")
            return
        }

        val currentlyPinned = _pinnedKeys.value
        val isAdding = affectedKeys.any { it !in currentlyPinned }

        val newSet = if (isAdding) {
            currentlyPinned + affectedKeys
        } else {
            currentlyPinned - affectedKeys.toSet()
        }

        _pinnedKeys.value = newSet
        Log.d("PIN_DEBUG", "Updated pinned keys: $newSet")
    }

    // Add this new function to delete entire categories
    fun deleteWorldCategory(category: String) {
        val updated = _gameState.value.worldState.toMutableMap()
        updated.remove(category)
        _gameState.value = _gameState.value.copy(worldState = JsonObject(updated))
        GameStateStorage.save(appContext, _gameState.value)
    }

    fun deleteWorldKey(fullKey: String) {
        Log.d("ViewModel", "deleteWorldKey called for: $fullKey")
        Log.d("ViewModel", "Before deletion - worldState: ${_gameState.value.worldState}")

        val segments = fullKey.split(".")
        if (segments.size < 2) return // Need at least "world.flags.x"

        val updated = _gameState.value.worldState.toMutableMap()
        val worldObj = updated["world"]?.jsonObject?.toMutableMap() ?: return

        // Find the exact flag key (which contains dots)
        val flagKey = segments.drop(1).joinToString(".") // gets "flags.restedHere"
        worldObj.remove(flagKey)

        updated["world"] = JsonObject(worldObj)

        val newWorldState = JsonObject(updated)
        Log.d("ViewModel", "After deletion - worldState: $newWorldState")

        _gameState.value = _gameState.value.copy(worldState = newWorldState)
        GameStateStorage.save(appContext, _gameState.value)
    }


    fun editWorldKey(fullKey: String, newValue: JsonElement) {
        val segments = fullKey.split(".")
        if (segments.isEmpty()) return

        val original = _gameState.value.worldState
        val updated = original.toMutableMap()

        var current: MutableMap<String, JsonElement> = updated

        for (i in 0 until segments.size - 1) {
            val obj = current[segments[i]] as? JsonObject ?: return
            val next = obj.toMutableMap()
            current[segments[i]] = JsonObject(next)
            current = next
        }

        current[segments.last()] = newValue
        val result = JsonObject(updated)
        _gameState.value = _gameState.value.copy(worldState = result)
        GameStateStorage.save(appContext, _gameState.value)
    }

    fun deleteEntity(category: String, entity: String, level: Int = 2) {
        val world = _gameState.value.worldState.toMutableMap()

        if (level == 2) {
            val entities = world["entities"]?.jsonObject?.toMutableMap() ?: return
            val entityType = entities[category]?.jsonObject?.toMutableMap() ?: return

            entityType.remove(entity)
            entities[category] = JsonObject(entityType)
            world["entities"] = JsonObject(entities)
        } else if (level == 1) {
            val cat = world[category]?.jsonObject?.toMutableMap() ?: return
            cat.remove(entity)
            world[category] = JsonObject(cat)
        } else {
            Log.w("ViewModel", "Unsupported deleteEntity level: $level")
            return
        }

        _gameState.value = _gameState.value.copy(worldState = JsonObject(world))
        GameStateStorage.save(appContext, _gameState.value)
    }

    fun renameEntity(category: String, oldName: String, newName: String) {
        if (oldName == newName || newName.isBlank()) return

        val world = _gameState.value.worldState.toMutableMap()
        val categoryMap = world[category]?.jsonObject?.toMutableMap() ?: return
        val oldEntity = categoryMap[oldName] ?: return

        if (categoryMap.containsKey(newName)) return

        // Apply rename
        categoryMap.remove(oldName)
        categoryMap[newName] = oldEntity
        world[category] = JsonObject(categoryMap)
        val updatedState = _gameState.value.copy(worldState = JsonObject(world))
        _gameState.value = updatedState

        // Rewrite pinned keys
        val oldPrefix = "$category.$oldName."
        val newPrefix = "$category.$newName."

        _pinnedKeys.update { current ->
            current.map {
                if (it.startsWith(oldPrefix)) newPrefix + it.removePrefix(oldPrefix) else it
            }.toSet()
        }

        GameStateStorage.save(appContext, updatedState)
    }

    fun renameCategory(oldName: String, newName: String) {
        if (oldName == newName || newName.isBlank()) return

        val world = _gameState.value.worldState.toMutableMap()
        if (!world.containsKey(oldName) || world.containsKey(newName)) return

        val oldValue = world[oldName] ?: return
        world.remove(oldName)
        world[newName] = oldValue

        val updatedState = _gameState.value.copy(worldState = JsonObject(world))
        _gameState.value = updatedState

        val oldPrefix = "$oldName."
        val newPrefix = "$newName."

        _pinnedKeys.update { keys ->
            keys.map { key ->
                if (key.startsWith(oldPrefix)) newPrefix + key.removePrefix(oldPrefix) else key
            }.toSet()
        }

        GameStateStorage.save(appContext, updatedState)
    }

}
