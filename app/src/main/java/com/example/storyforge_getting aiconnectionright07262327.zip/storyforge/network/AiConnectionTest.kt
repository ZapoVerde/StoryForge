package com.example.storyforge.network

import com.example.storyforge.settings.AiConnection
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonPrimitive
import java.net.HttpURLConnection
import java.net.URL

object AiConnectionTester {

    suspend fun testConnection(connection: AiConnection): Boolean {
        return try {
            val url = URL(connection.apiUrl.trimEnd('/') + "/chat/completions")
            val conn = url.openConnection() as HttpURLConnection
            conn.requestMethod = "POST"
            conn.setRequestProperty("Authorization", "Bearer ${connection.apiToken}")
            conn.setRequestProperty("Content-Type", "application/json")
            conn.doOutput = true
            conn.connectTimeout = 5000
            conn.readTimeout = 5000

            val body = """
                {
                  "model": "deepseek-chat",
                  "messages": [
                    {"role": "user", "content": "ping"}
                  ],
                  "stream": false
                }
            """.trimIndent()

            conn.outputStream.use { it.write(body.toByteArray()) }

            val responseText = conn.inputStream.bufferedReader().readText()
            conn.disconnect()

            val json = Json.parseToJsonElement(responseText).jsonObject
            val content = json["choices"]
                ?.jsonArray?.getOrNull(0)
                ?.jsonObject?.get("message")
                ?.jsonObject?.get("content")
                ?.jsonPrimitive?.contentOrNull

            !content.isNullOrBlank()
        } catch (e: Exception) {
            false
        }
    }
}
