package com.example.storyforge.ui.screens

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import java.io.File

enum class LogType(val displayName: String, val filename: String) {
    DIGEST("Digest", "digest_log.jsonl"),
    WORLDSTATE("WorldState", "worldstate_log.jsonl"),
    TURN("Turn Log", "turn_log.jsonl")

}

@Composable
fun LogViewerScreen(context: Context, onNavToggle: () -> Unit) {
    var selectedLog by remember { mutableStateOf(LogType.DIGEST) }
    var logLines by remember { mutableStateOf(listOf("(loading...)")) }

    LaunchedEffect(selectedLog) {
        val file = File(context.filesDir, selectedLog.filename)
        logLines = if (file.exists()) file.readLines() else listOf("(No entries found)")
    }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Log Viewer", style = MaterialTheme.typography.headlineSmall)
            TextButton(onClick = onNavToggle) { Text("Menu") }
        }

        Spacer(modifier = Modifier.height(12.dp))

        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Select Log:", modifier = Modifier.padding(end = 8.dp))
            var expanded by remember { mutableStateOf(false) }
            Box {
                Button(onClick = { expanded = true }) {
                    Text(selectedLog.displayName)
                }
                DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                    LogType.values().forEach { logType ->
                        DropdownMenuItem(
                            text = { Text(logType.displayName) },
                            onClick = {
                                selectedLog = logType
                                expanded = false
                            }
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        LazyColumn(modifier = Modifier.fillMaxSize().background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.1f))) {
            items(logLines) { line ->
                Column(modifier = Modifier.padding(vertical = 4.dp, horizontal = 8.dp)) {
                    Text(
                        text = line,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Divider(modifier = Modifier.padding(vertical = 4.dp))
                }
            }
        }
    }
}
