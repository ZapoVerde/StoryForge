// file: com/example/storyforge/StoryForgeViewModel.kt
package com.example.storyforge

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.storyforge.core.Narrator
import com.example.storyforge.model.GameState
import com.example.storyforge.model.GameStateSlotStorage
import com.example.storyforge.model.GameStateStorage
import com.example.storyforge.prompt.PromptCard
import com.example.storyforge.prompt.PromptCardStorage
import com.example.storyforge.settings.Settings
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import android.content.Context
import android.util.Log
import com.example.storyforge.core.AINarrator
import com.example.storyforge.core.DummyNarrator
import com.example.storyforge.model.Message
import com.example.storyforge.prompt.AiSettings
import com.example.storyforge.ui.screens.flattenJsonObject
import kotlinx.serialization.json.*
import com.example.storyforge.core.NarrationParser
import com.example.storyforge.core.DigestManager
import com.example.storyforge.core.PromptAssembler
import com.example.storyforge.core.SceneManager
import com.example.storyforge.model.WorldStateLog
import com.example.storyforge.model.TurnLog
import com.example.storyforge.model.DeltaInstruction
import com.example.storyforge.model.ConversationTurn
import com.example.storyforge.settings.AiConnection

data class Turn(val action: String, val narration: String)

class StoryForgeViewModel(
    private val narratorFactory: () -> Narrator,
    private val _settings: Settings,
    private val promptCardStorage: PromptCardStorage,
    val appContext: Context
) : ViewModel() {

    private val _gameState = MutableStateFlow(GameStateStorage.load(appContext))
    private val _promptCards = MutableStateFlow<List<PromptCard>>(emptyList())
    private val _turns = MutableStateFlow<List<Turn>>(emptyList())
    private val _errorMessage = MutableStateFlow<String?>(null)
    private val _isProcessing = MutableStateFlow(false)
    private val _worldChangeMessage = MutableStateFlow<String?>(null)
    private val _pinnedKeys = MutableStateFlow<Set<String>>(emptySet())
    private val _activePromptCard = MutableStateFlow<PromptCard?>(null)
    private val _useDummyNarrator = MutableStateFlow<Boolean>(false)
    private val _aiConnections = MutableStateFlow(_settings.aiConnections)

    val aiConnections: StateFlow<List<AiConnection>> = _aiConnections.asStateFlow()
    val activePromptCard: StateFlow<PromptCard?> = _activePromptCard.asStateFlow()
    val gameState: StateFlow<GameState> = _gameState.asStateFlow()
    val promptCards: StateFlow<List<PromptCard>> = _promptCards.asStateFlow()
    val turns: StateFlow<List<Turn>> = _turns.asStateFlow()
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()
    val isProcessing: StateFlow<Boolean> = _isProcessing.asStateFlow()
    val worldChangeMessage: StateFlow<String?> = _worldChangeMessage.asStateFlow()
    val pinnedKeys: StateFlow<Set<String>> = _pinnedKeys.asStateFlow()
    val settings: Settings
        get() = _settings

    fun updateAiConnections(newList: List<AiConnection>) {
        _aiConnections.value = newList
        // If you want to save it to disk, do that here:
        // SettingsManager.saveAiConnections(newList)
    }



    fun setUseDummyNarrator(enabled: Boolean) {
        _useDummyNarrator.value = enabled
    }

    fun isUsingDummyNarrator(): Boolean {
        return _useDummyNarrator.value
    }

    val useDummyNarrator: StateFlow<Boolean> = _useDummyNarrator.asStateFlow()

    init {
        _promptCards.value = promptCardStorage.loadDefaultsIfEmpty()

        viewModelScope.launch {
            _pinnedKeys.collect { keys ->
                Log.d("PIN_DEBUG", "Pinned keys updated: $keys")
            }
        }
    }

    fun setActivePromptCard(card: PromptCard) {
        // 🚫 Reject blank title
        if (card.title.trim().isEmpty()) {
            Log.w("PromptCard", "Refused to activate card — missing title")
            return
        }

        _activePromptCard.value = card

        val initBlock = card.worldStateInit.trim()
        if (initBlock.isNotBlank()) {
            try {
                val parsed = Json.parseToJsonElement(initBlock).jsonObject

                // ✅ Enforce 3-level world state structure
                val allValid = parsed.values.all { top ->
                    top is JsonObject && top.values.all { it is JsonObject }
                }

                if (!allValid) {
                    Log.w("PromptCard", "Refused to load worldStateInit — not a 3-level object")
                    return
                }

                _gameState.value = _gameState.value.copy(worldState = parsed)

            } catch (e: Exception) {
                Log.e("PromptCard", "Failed to parse structured worldStateInit", e)
            }
        }
    }



    fun addPromptCard(card: PromptCard) {
        _promptCards.update { current ->
            val updated = current.toMutableList()
            val index = updated.indexOfFirst { it.id == card.id }

            if (index != -1) {
                updated[index] = card  // ✅ update in-place
            } else {
                updated.add(card)      // ✅ append new
            }

            promptCardStorage.saveCards(updated)
            updated
        }
    }


    fun deletePromptCard(id: String) {
        _promptCards.update { current ->
            val updated = current.filterNot { it.id == id }
            promptCardStorage.saveCards(updated)
            updated
        }
    }

    fun togglePin(prefixKey: String) {
        Log.d("PIN_DEBUG", "Toggling pin for: $prefixKey")

        val flatWorld = flattenJsonObject(_gameState.value.worldState)
        val affectedKeys = flatWorld.keys.filter { it.startsWith(prefixKey) }

        if (affectedKeys.isEmpty()) {
            Log.w("PIN_DEBUG", "No keys matched for $prefixKey")
            return
        }

        val currentlyPinned = _pinnedKeys.value
        val isAdding = affectedKeys.any { it !in currentlyPinned }

        val newSet = if (isAdding) {
            currentlyPinned + affectedKeys
        } else {
            currentlyPinned - affectedKeys.toSet()
        }

        _pinnedKeys.value = newSet
        Log.d("PIN_DEBUG", "Updated pinned keys: $newSet")
    }

    private fun resolveNarrator(): Narrator {
        if (_useDummyNarrator.value) return DummyNarrator()

        val promptCard = _activePromptCard.value ?: return DummyNarrator()
        val connectionId = promptCard.aiSettings.selectedConnectionId
        val connection = _settings.aiConnections.find { it.id == connectionId }
        if (connection == null) {
            Log.w("Narrator", "No connection found for ID: $connectionId")
        }


        return try {
            if (connection == null || !connection.apiUrl.trim().startsWith("http")) {
                DummyNarrator()
            } else {
                AINarrator.fromConnection(connection)
            }
        } catch (e: Exception) {
            DummyNarrator()
        }
    }

    fun processAction(action: String) {
        if (action.isBlank()) {
            _errorMessage.value = "Action cannot be empty"
            return
        }

        _turns.value += Turn(action = action, narration = "")

        viewModelScope.launch {
            _isProcessing.value = true
            _errorMessage.value = null

            val turnId = _turns.value.size - 1
            val narrator = resolveNarrator()

            // Generate placeholder input (real input comes after narration)
            val assembledMessages = listOf(
                Message(role = "user", content = action)
            )

            val narrationResult = narrator.generate(
                messages = assembledMessages, // will be replaced below
                settings = AiSettings(),
                modelName = "fallback",
                turnId = turnId,
                context = appContext
            )

            val result = narrationResult.getOrNull()
            if (result == null) {
                _errorMessage.value = "Narration failed"
                _isProcessing.value = false
                return@launch
            }

            val (prose, deltas) = result
            val parsed = NarrationParser.extractJsonAndCleanNarration(prose)

            // SceneManager integration
            if (parsed.sceneBlock != null) {
                SceneManager.onSceneBlock(parsed.sceneBlock, appContext, turnId)
            } else {
                SceneManager.onDeltas(deltas, appContext, turnId)
            }

            val worldState = _gameState.value.worldState
            val scenePaths = SceneManager.getSceneTags(worldState)


            val promptInput = PromptAssembler.PromptAssemblerInput(
                promptCard = _activePromptCard.value!!,
                bufferTurns = _turns.value.map { ConversationTurn(it.action, it.narration) },
                digestLines = emptyList(),
                worldState = emptyMap(),
                characterState = emptyMap(),
                userMessage = action
            )

            val finalPrompt = PromptAssembler.assemble(
                input = promptInput,
                scenePaths = scenePaths,
                worldStateJson = worldState
            )

            // 🔁 Now re-run narration using the full prompt
            val enrichedResult = narrator.generate(
                messages = finalPrompt.messages,
                settings = AiSettings(),
                modelName = "fallback",
                turnId = turnId,
                context = appContext
            )

            val enrichedProse = enrichedResult.getOrNull()?.first ?: prose

            _turns.update { old -> old.dropLast(1) + Turn(action = action, narration = enrichedProse) }

            TurnLog.append(appContext, turnId, action, enrichedProse)

            val taggedDeltas = deltas.mapValues { (key, instruction) ->
                if (instruction is DeltaInstruction.Declare) {
                    val pathParts = instruction.key.split(".")
                    if (pathParts.size >= 2) {
                        val (category, _) = pathParts
                        val valueObj = instruction.value as? JsonObject ?: return@mapValues instruction
                        if (!valueObj.containsKey("tag")) {
                            val inferredTag = when (category) {
                                "npcs", "entities" -> "character"
                                "locations", "places" -> "location"
                                else -> null
                            }
                            if (inferredTag != null) {
                                val patched = valueObj.toMutableMap()
                                patched["tag"] = JsonPrimitive(inferredTag)
                                return@mapValues DeltaInstruction.Declare(instruction.key, JsonObject(patched))
                            }
                        }
                    }
                }
                instruction
            }

            _gameState.value.applyDeltas(taggedDeltas)
            GameStateStorage.save(appContext, _gameState.value)

            WorldStateLog.append(appContext, turnId, taggedDeltas)
            DigestManager.addParsedLines(appContext, turnId, enrichedProse, taggedDeltas)

            _isProcessing.value = false
        }
    }


    fun GameState.buildMessageList(action: String): List<Message> {
        val priorTurns = turns.value.map { Turn(it.action, it.narration) }
        val history = priorTurns.flatMap {
            listOf(
                Message(role = "user", content = it.action),
                Message(role = "assistant", content = it.narration)
            )
        }
        return history + Message(role = "user", content = action)
    }

    fun clearError() {
        _errorMessage.value = null
    }

    fun saveToSlot(promptCardName: String) {
        GameStateSlotStorage.saveSlot(appContext, _gameState.value, promptCardName)
    }

    fun resetSession(newState: GameState = GameState()) {
        _gameState.value = newState
        _turns.value = emptyList()
        _errorMessage.value = null
        _isProcessing.value = false
    }

    fun deleteWorldCategory(category: String) {
        val updated = _gameState.value.worldState.toMutableMap()
        updated.remove(category)
        _gameState.value = _gameState.value.copy(worldState = JsonObject(updated))
        GameStateStorage.save(appContext, _gameState.value)
    }

    fun deleteWorldKey(fullKey: String) {
        val segments = fullKey.split(".")
        if (segments.size < 2) return

        val updated = _gameState.value.worldState.toMutableMap()
        val worldObj = updated["world"]?.jsonObject?.toMutableMap() ?: return

        val flagKey = segments.drop(1).joinToString(".")
        worldObj.remove(flagKey)
        updated["world"] = JsonObject(worldObj)

        val newWorldState = JsonObject(updated)
        _gameState.value = _gameState.value.copy(worldState = newWorldState)
        GameStateStorage.save(appContext, _gameState.value)
    }

    fun editWorldKey(fullKey: String, newValue: JsonElement) {
        val segments = fullKey.split(".")
        if (segments.isEmpty()) return

        val original = _gameState.value.worldState
        val updated = original.toMutableMap()
        var current: MutableMap<String, JsonElement> = updated

        for (i in 0 until segments.size - 1) {
            val obj = current[segments[i]] as? JsonObject ?: return
            val next = obj.toMutableMap()
            current[segments[i]] = JsonObject(next)
            current = next
        }

        current[segments.last()] = newValue
        val newWorldState = JsonObject(updated)
        _gameState.value = _gameState.value.copy(worldState = newWorldState)
        GameStateStorage.save(appContext, _gameState.value)
    }

    fun deleteEntity(category: String, entity: String, level: Int = 2) {
        val world = _gameState.value.worldState.toMutableMap()

        if (level == 2) {
            val entities = world["entities"]?.jsonObject?.toMutableMap() ?: return
            val entityType = entities[category]?.jsonObject?.toMutableMap() ?: return

            entityType.remove(entity)
            entities[category] = JsonObject(entityType)
            world["entities"] = JsonObject(entities)
        } else if (level == 1) {
            val cat = world[category]?.jsonObject?.toMutableMap() ?: return
            cat.remove(entity)
            world[category] = JsonObject(cat)
        } else {
            return
        }

        _gameState.value = _gameState.value.copy(worldState = JsonObject(world))
        GameStateStorage.save(appContext, _gameState.value)
    }

    fun renameEntity(category: String, oldName: String, newName: String) {
        if (oldName == newName || newName.isBlank()) return

        val world = _gameState.value.worldState.toMutableMap()
        val categoryMap = world[category]?.jsonObject?.toMutableMap() ?: return
        val oldEntity = categoryMap[oldName] ?: return

        if (categoryMap.containsKey(newName)) return

        categoryMap.remove(oldName)
        categoryMap[newName] = oldEntity
        world[category] = JsonObject(categoryMap)
        val updatedState = _gameState.value.copy(worldState = JsonObject(world))
        _gameState.value = updatedState

        val oldPrefix = "$category.$oldName."
        val newPrefix = "$category.$newName."

        _pinnedKeys.update { current ->
            current.map {
                if (it.startsWith(oldPrefix)) newPrefix + it.removePrefix(oldPrefix) else it
            }.toSet()
        }

        GameStateStorage.save(appContext, updatedState)
    }

    fun renameCategory(oldName: String, newName: String) {
        if (oldName == newName || newName.isBlank()) return

        val world = _gameState.value.worldState.toMutableMap()
        if (!world.containsKey(oldName) || world.containsKey(newName)) return

        val oldValue = world[oldName] ?: return
        world.remove(oldName)
        world[newName] = oldValue

        val updatedState = _gameState.value.copy(worldState = JsonObject(world))
        _gameState.value = updatedState

        val oldPrefix = "$oldName."
        val newPrefix = "$newName."

        _pinnedKeys.update { keys ->
            keys.map { key ->
                if (key.startsWith(oldPrefix)) newPrefix + key.removePrefix(oldPrefix) else key
            }.toSet()
        }

        GameStateStorage.save(appContext, updatedState)
    }
}
