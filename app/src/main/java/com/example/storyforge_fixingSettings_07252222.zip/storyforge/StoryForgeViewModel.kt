package com.example.storyforge

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.storyforge.core.NarrationParser
import com.example.storyforge.core.Narrator
import com.example.storyforge.model.GameState
import com.example.storyforge.model.GameStateSlotStorage
import com.example.storyforge.model.GameStateStorage
import com.example.storyforge.prompt.PromptCard
import com.example.storyforge.prompt.PromptCardStorage
import com.example.storyforge.settings.Settings
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import android.content.Context
import android.util.Log
import com.example.storyforge.ui.screens.flattenJsonObject
import kotlinx.serialization.json.*

data class Turn(val action: String, val narration: String)

class StoryForgeViewModel(
    private val aiNarrator: Narrator,
    private val settings: Settings,
    private val promptCardStorage: PromptCardStorage,
    val appContext: Context
) : ViewModel() {

    private val _gameState = MutableStateFlow(GameStateStorage.load(appContext))
    private val _promptCards = MutableStateFlow<List<PromptCard>>(emptyList())
    private val _turns = MutableStateFlow<List<Turn>>(emptyList())
    private val _errorMessage = MutableStateFlow<String?>(null)
    private val _isProcessing = MutableStateFlow(false)
    private val _worldChangeMessage = MutableStateFlow<String?>(null)
    private val _pinnedKeys = MutableStateFlow<Set<String>>(emptySet())

    val gameState: StateFlow<GameState> = _gameState.asStateFlow()
    val promptCards: StateFlow<List<PromptCard>> = _promptCards.asStateFlow()
    val turns: StateFlow<List<Turn>> = _turns.asStateFlow()
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()
    val isProcessing: StateFlow<Boolean> = _isProcessing.asStateFlow()
    val worldChangeMessage: StateFlow<String?> = _worldChangeMessage.asStateFlow()
    val pinnedKeys: StateFlow<Set<String>> = _pinnedKeys.asStateFlow()

    init {
        _promptCards.value = promptCardStorage.loadDefaultsIfEmpty()


        // Debug the pinned keys flow
        viewModelScope.launch {
            _pinnedKeys.collect { keys ->
                Log.d("PIN_DEBUG", "Pinned keys updated: $keys")
            }
        }
    }

    fun addPromptCard(card: PromptCard) {
        _promptCards.update { current ->
            val updated = current + card
            promptCardStorage.saveCards(updated)
            updated
        }
    }

    fun deletePromptCard(id: String) {
        _promptCards.update { current ->
            val updated = current.filterNot { it.id == id }
            promptCardStorage.saveCards(updated)
            updated
        }
    }

    fun processAction(action: String) {
        if (action.isBlank()) {
            _errorMessage.value = "Action cannot be empty"
            return
        }

        _turns.value += Turn(action = action, narration = "")

        viewModelScope.launch {
            _isProcessing.value = true
            _errorMessage.value = null

            val narrationResult = aiNarrator.generate(action, _gameState.value)

            narrationResult.fold(
                onSuccess = { (narration, parsedDeltas) ->
                    _gameState.value = _gameState.value.apply {
                        this.narration = narration
                        applyDeltas(parsedDeltas)
                    }

                    NarrationParser.logDeltas(parsedDeltas)
                    GameStateStorage.save(appContext, _gameState.value)

                    val current = _turns.value
                    if (current.isNotEmpty()) {
                        _turns.value = current.dropLast(1) + Turn(action = action, narration = narration)
                    }

                    val changeKeys = parsedDeltas.keys.joinToString(", ")
                    if (changeKeys.isNotBlank()) {
                        _worldChangeMessage.value = "World updated: $changeKeys"
                        launch {
                            delay(3000)
                            _worldChangeMessage.value = null
                        }
                    }
                },
                onFailure = { error ->
                    _errorMessage.value = when (error) {
                        is IllegalStateException -> "Server error: ${error.message}"
                        else -> "Action failed: ${error.localizedMessage}"
                    }
                }
            )

            _isProcessing.value = false
        }
    }

    fun clearError() {
        _errorMessage.value = null
    }

    fun saveToSlot(promptCardName: String) {
        GameStateSlotStorage.saveSlot(appContext, _gameState.value, promptCardName)
    }

    fun setGameState(state: GameState) {
        _gameState.value = state
    }

    fun resetSession(newState: GameState = GameState()) {
        _gameState.value = newState
        _turns.value = emptyList()
        _errorMessage.value = null
        _isProcessing.value = false
    }

    fun togglePin(prefixKey: String) {
        Log.d("PIN_DEBUG", "Toggling pin for: $prefixKey")

        val flatWorld = flattenJsonObject(_gameState.value.worldState)
        val affectedKeys = flatWorld.keys.filter { it.startsWith(prefixKey) }

        if (affectedKeys.isEmpty()) {
            Log.w("PIN_DEBUG", "No keys matched for $prefixKey")
            return
        }

        val currentlyPinned = _pinnedKeys.value
        val isAdding = affectedKeys.any { it !in currentlyPinned }

        val newSet = if (isAdding) {
            currentlyPinned + affectedKeys
        } else {
            currentlyPinned - affectedKeys.toSet()
        }

        _pinnedKeys.value = newSet
        Log.d("PIN_DEBUG", "Updated pinned keys: $newSet")
    }



    fun removeWorldKey(key: String) {
        val (target, variable) = key.split(".", limit = 2).takeIf { it.size == 2 } ?: return
        val world = _gameState.value.worldState.toMutableMap().toMutableMap()
        val section = world[target]?.jsonObject?.toMutableMap() ?: return
        section.remove(variable)
        world[target] = JsonObject(section)
        _gameState.update {
            it.copy(worldState = JsonObject(world))
        }
    }

    fun updateWorldKey(key: String, newValue: JsonElement) {
        val (target, variable) = key.split(".", limit = 2).takeIf { it.size == 2 } ?: return
        val world = _gameState.value.worldState.toMutableMap().toMutableMap()
        val section = world[target]?.jsonObject?.toMutableMap() ?: mutableMapOf()
        section[variable] = newValue
        world[target] = JsonObject(section)
        _gameState.update {
            it.copy(worldState = JsonObject(world))
        }
    }
    // Add this new function to delete entire categories
    fun deleteWorldCategory(category: String) {
        val updated = _gameState.value.worldState.toMutableMap()
        updated.remove(category)
        _gameState.value = _gameState.value.copy(worldState = JsonObject(updated))
        GameStateStorage.save(appContext, _gameState.value)
    }

    fun deleteWorldKey(fullKey: String) {
        Log.d("ViewModel", "deleteWorldKey called for: $fullKey")
        Log.d("ViewModel", "Before deletion - worldState: ${_gameState.value.worldState}")

        val segments = fullKey.split(".")
        if (segments.size < 2) return // Need at least "world.flags.x"

        val updated = _gameState.value.worldState.toMutableMap()
        val worldObj = updated["world"]?.jsonObject?.toMutableMap() ?: return

        // Find the exact flag key (which contains dots)
        val flagKey = segments.drop(1).joinToString(".") // gets "flags.restedHere"
        worldObj.remove(flagKey)

        updated["world"] = JsonObject(worldObj)

        val newWorldState = JsonObject(updated)
        Log.d("ViewModel", "After deletion - worldState: $newWorldState")

        _gameState.value = _gameState.value.copy(worldState = newWorldState)
        GameStateStorage.save(appContext, _gameState.value)
    }


    fun editWorldKey(fullKey: String, newValue: JsonElement) {
        val segments = fullKey.split(".")
        if (segments.isEmpty()) return

        val original = _gameState.value.worldState
        val updated = original.toMutableMap()

        var current: MutableMap<String, JsonElement> = updated

        for (i in 0 until segments.size - 1) {
            val obj = current[segments[i]] as? JsonObject ?: return
            val next = obj.toMutableMap()
            current[segments[i]] = JsonObject(next)
            current = next
        }

        current[segments.last()] = newValue
        val result = JsonObject(updated)
        _gameState.value = _gameState.value.copy(worldState = result)
        GameStateStorage.save(appContext, _gameState.value)
    }

    // Add this function to get pinned items with their values
    fun getPinnedItems(): List<Pair<String, JsonElement>> {
        val flatWorld = flattenJsonObject(_gameState.value.worldState)
        return _pinnedKeys.value.mapNotNull { key ->
            flatWorld[key]?.let { key to it }
        }
    }

    // Helper extension for JSON value lookup
    private fun JsonObject.findValue(fullKey: String): JsonElement? {
        val segments = fullKey.split(".")
        if (segments.size < 2) return null

        return try {
            // First try to handle as nested structure
            var current: JsonElement = this
            for (segment in segments) {
                current = (current as? JsonObject)?.get(segment) ?: break
            }

            // If that fails, try to find exact match with dots in key names
            if (current == null || current is JsonNull) {
                this.entries.find { it.key == fullKey }?.value
            } else {
                current
            }
        } catch (e: Exception) {
            Log.e("ViewModel", "Error finding value for $fullKey", e)
            null
        }
    }

    // Get all entities of a type
    fun getEntities(type: String): List<Pair<String, JsonObject>> {
        return (_gameState.value.worldState["entities"]?.jsonObject
            ?.get(type)?.jsonObject?.toMap() ?: emptyMap())
            .map { (id, data) -> id to data.jsonObject }
    }

    // Update specific entity attribute
    fun updateEntity(type: String, id: String, attr: String, value: JsonElement) {
        if (value is JsonNull) {
            deleteEntityAttribute(type, id, attr)
            return
        }
        val world = _gameState.value.worldState.toMutableMap()
        val entities = world["entities"]?.jsonObject?.toMutableMap() ?: mutableMapOf()
        val entityType = entities[type]?.jsonObject?.toMutableMap() ?: mutableMapOf()

        entityType[id]?.let {
            val entity = it.jsonObject.toMutableMap()
            entity[attr] = value
            entityType[id] = JsonObject(entity)
        }

        entities[type] = JsonObject(entityType)
        world["entities"] = JsonObject(entities)
        _gameState.value = _gameState.value.copy(worldState = JsonObject(world))
    }
    fun deleteEntityAttribute(type: String, id: String, attr: String) {
        val world = _gameState.value.worldState.toMutableMap()
        val entities = world["entities"]?.jsonObject?.toMutableMap() ?: return
        val entityType = entities[type]?.jsonObject?.toMutableMap() ?: return
        val entity = entityType[id]?.jsonObject?.toMutableMap() ?: return

        entity.remove(attr)
        entityType[id] = JsonObject(entity)
        entities[type] = JsonObject(entityType)
        world["entities"] = JsonObject(entities)

        _gameState.value = _gameState.value.copy(worldState = JsonObject(world))
        GameStateStorage.save(appContext, _gameState.value)
    }
    fun deleteEntity(category: String, entity: String, level: Int = 2) {
        val world = _gameState.value.worldState.toMutableMap()

        if (level == 2) {
            val entities = world["entities"]?.jsonObject?.toMutableMap() ?: return
            val entityType = entities[category]?.jsonObject?.toMutableMap() ?: return

            entityType.remove(entity)
            entities[category] = JsonObject(entityType)
            world["entities"] = JsonObject(entities)
        } else if (level == 1) {
            val cat = world[category]?.jsonObject?.toMutableMap() ?: return
            cat.remove(entity)
            world[category] = JsonObject(cat)
        } else {
            Log.w("ViewModel", "Unsupported deleteEntity level: $level")
            return
        }

        _gameState.value = _gameState.value.copy(worldState = JsonObject(world))
        GameStateStorage.save(appContext, _gameState.value)
    }

    fun renameEntity(category: String, oldName: String, newName: String) {
        if (oldName == newName || newName.isBlank()) return

        val world = _gameState.value.worldState.toMutableMap()
        val categoryMap = world[category]?.jsonObject?.toMutableMap() ?: return
        val oldEntity = categoryMap[oldName] ?: return

        if (categoryMap.containsKey(newName)) return

        // Apply rename
        categoryMap.remove(oldName)
        categoryMap[newName] = oldEntity
        world[category] = JsonObject(categoryMap)
        val updatedState = _gameState.value.copy(worldState = JsonObject(world))
        _gameState.value = updatedState

        // Rewrite pinned keys
        val oldPrefix = "$category.$oldName."
        val newPrefix = "$category.$newName."

        _pinnedKeys.update { current ->
            current.map {
                if (it.startsWith(oldPrefix)) newPrefix + it.removePrefix(oldPrefix) else it
            }.toSet()
        }

        GameStateStorage.save(appContext, updatedState)
    }

    fun renameCategory(oldName: String, newName: String) {
        if (oldName == newName || newName.isBlank()) return

        val world = _gameState.value.worldState.toMutableMap()
        if (!world.containsKey(oldName) || world.containsKey(newName)) return

        val oldValue = world[oldName] ?: return
        world.remove(oldName)
        world[newName] = oldValue

        val updatedState = _gameState.value.copy(worldState = JsonObject(world))
        _gameState.value = updatedState

        val oldPrefix = "$oldName."
        val newPrefix = "$newName."

        _pinnedKeys.update { keys ->
            keys.map { key ->
                if (key.startsWith(oldPrefix)) newPrefix + key.removePrefix(oldPrefix) else key
            }.toSet()
        }

        GameStateStorage.save(appContext, updatedState)
    }

}
