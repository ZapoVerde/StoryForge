package com.example.storyforge.core

import android.util.Log
import com.example.storyforge.model.GameState
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch

private const val TAG = "DeltaEngine"

class DeltaEngine(
    private val aiNarrator: AINarrator,
    private val gameState: GameState,
    private val coroutineScope: CoroutineScope,
    private val onStateUpdated: (String, GameState) -> Unit,
    private val onError: (String) -> Unit = { Log.e(TAG, it) }
) {
//** Processes a player action through the narration pipeline


    fun process(action: String) {
        if (action.isBlank()) {
            onError("Empty action received")
            return
        }

        coroutineScope.launch {
            Log.d(TAG, "Processing action: '$action'")

            val result = aiNarrator.generate(action, gameState)

            if (result.isSuccess) {
                val (narration, deltas) = result.getOrThrow()
                gameState.applyDeltas(deltas)
                Log.d(TAG, "Action '$action' processed successfully")
                onStateUpdated(narration, gameState)
            } else {
                val exception = result.exceptionOrNull()
                val errorMsg = "Narration failed for '$action': ${exception?.message ?: "Unknown error"}"
                Log.e(TAG, errorMsg, exception)
                onError(errorMsg)
                onStateUpdated("The story seems stuck... Try again?", gameState)
            }
        }
    }
}
