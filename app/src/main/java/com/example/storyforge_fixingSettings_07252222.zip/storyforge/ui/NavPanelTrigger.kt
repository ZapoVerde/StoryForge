package com.example.storyforge.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController

@Composable
fun HiddenNavOverlay(
    navController: NavController,
    content: @Composable () -> Unit
) {
    var showMenu by remember { mutableStateOf(false) }

    Box(modifier = Modifier.fillMaxSize()) {
        content()

        // Invisible center tap zone
        Box(
            modifier = Modifier
                .size(100.dp)
                .align(Alignment.Center)
                .clickable { showMenu = true }
        ) {}

        if (showMenu) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0x80000000)) // translucent overlay
                    .clickable { showMenu = false }
            ) {}

            Column(
                modifier = Modifier
                    .align(Alignment.Center)
                    .background(MaterialTheme.colorScheme.surface)
                    .padding(16.dp)
            ) {
                Text("Navigation", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(8.dp))
                Button(onClick = {
                    navController.navigate("narrator")
                    showMenu = false
                }) {
                    Text("Narrator")
                }
                Button(onClick = {
                    navController.navigate("prompt_cards")
                    showMenu = false
                }) {
                    Text("Prompt Cards")
                }
                Button(onClick = {
                    navController.navigate("world_state")
                    showMenu = false
                }) {
                    Text("World State")
                }
            }
        }
    }
}
