package com.example.storyforge.model

import android.content.Context
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.File

object WorldStateLog {
    private const val LOG_FILE = "state_changes_log.jsonl"

    fun append(entry: Map<String, Any>, context: Context? = null) {
        try {
            val file = context?.filesDir?.let { File(it, LOG_FILE) }
            file?.appendText(Json.encodeToString(entry) + "\n")
        } catch (_: Exception) {
            // Silent fail
        }
    }
}
