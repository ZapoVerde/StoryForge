package com.example.storyforge.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.storyforge.settings.AiConnection
import java.util.*

@Composable
fun AiConnectionEditor(
    connection: AiConnection?,
    onSave: (AiConnection) -> Unit,
    onCancel: () -> Unit
) {
    var displayName by remember { mutableStateOf(connection?.displayName ?: "") }
    var description by remember { mutableStateOf(connection?.description ?: "") }
    var apiUrl by remember { mutableStateOf(connection?.apiUrl ?: "") }
    var apiToken by remember { mutableStateOf(connection?.apiToken ?: "") }
    var functionCalling by remember { mutableStateOf(connection?.functionCallingEnabled ?: false) }

    Column(modifier = Modifier.fillMaxWidth().padding(12.dp)) {
        OutlinedTextField(
            value = displayName,
            onValueChange = { displayName = it },
            label = { Text("Display Name") },
            modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
            value = description,
            onValueChange = { description = it },
            label = { Text("Description (optional)") },
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 8.dp)
        )

        OutlinedTextField(
            value = apiUrl,
            onValueChange = { apiUrl = it },
            label = { Text("API URL") },
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 8.dp)
        )

        OutlinedTextField(
            value = apiToken,
            onValueChange = { apiToken = it },
            label = { Text("API Token") },
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 8.dp)
        )

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text("Function Calling Enabled")
            Switch(
                checked = functionCalling,
                onCheckedChange = { functionCalling = it }
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Button(
                onClick = {
                    val now = System.currentTimeMillis()
                    onSave(
                        AiConnection(
                            id = connection?.id ?: UUID.randomUUID().toString(),
                            displayName = displayName,
                            description = description.ifBlank { null },
                            apiUrl = apiUrl,
                            apiToken = apiToken,
                            functionCallingEnabled = functionCalling,
                            dateAdded = connection?.dateAdded ?: now,
                            lastUpdated = now
                        )
                    )
                },
                enabled = displayName.isNotBlank() && apiUrl.isNotBlank() && apiToken.isNotBlank()
            ) {
                Text("Save")
            }

            TextButton(onClick = onCancel) {
                Text("Cancel")
            }
        }
    }
}
