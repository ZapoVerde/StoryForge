package com.example.storyforge.core

import com.example.storyforge.model.DeltaInstruction
import com.example.storyforge.model.GameState
import kotlinx.coroutines.delay

class DummyNarrator : Narrator {
    override suspend fun generate(
        action: String,
        state: GameState
    ): Result<Pair<String, Map<String, DeltaInstruction>>> {
        delay(300)

        val response: String = when (action.trim().lowercase()) {
            "1" -> """
                You sift through the rubble of the old ruins. Dust clings to your fingers, but you find a stash of scrap.
                ```json
                {
                    "!enemies.goblin_1": {"hp":6, "status":"hostile"},
                    "!enemies.goblin_2": {"hp":4, "status":"fleeing"},
                    "!enemies.goblin_3": {"hp":8, "status":"angry"}
                }
                ```
            """.trimIndent()

            "2" -> """
                You press deeper into the forest. Twisting roots slow your path, but signs of an old camp emerge.
                ```json
                {
                  "=world.location": "deep_forest",
                  "!world.flags.enteredForest": true,
                  "+inventory.torches": 1
                }
                ```
            """.trimIndent()

            "3" -> """
                You make a simple camp and rest. The fire crackles as you settle in for the night.
                ```json
                {
                  "!player.status.rested": true,
                  "!world.flags.restedHere": true
                }
                ```
            """.trimIndent()

            "4" -> """
                You wander without clear direction. The terrain shifts around you, unfamiliar and vast.
                ```json
                {
                  "=world.location": "unknown",
                  "!world.flags.exploring": true
                }
                ```
            """.trimIndent()

            else -> """
                You hesitate, unsure what to do next.
                ```json
                {
                  "!world.flags.idle": true
                }
                ```
            """.trimIndent()
        }

        return Result.success(NarrationParser.extractJsonAndCleanNarration(response))
    }
}
