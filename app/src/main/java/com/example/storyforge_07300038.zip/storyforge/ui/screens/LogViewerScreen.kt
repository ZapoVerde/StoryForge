package com.example.storyforge.ui.screens

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import java.io.File
import com.example.storyforge.model.DigestLine
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.json.Json
import com.example.storyforge.model.StackLogEntry




enum class LogType(val displayName: String, val filename: String) {
    DIGEST("Digest", "digest_log.jsonl"),
    WORLDSTATE("WorldState", "worldstate_log.jsonl"),
    TURN("Turn Log", "turn_log.jsonl"),
    STACK("Narrator Stack", "stack_trace_log.jsonl")


}

fun loadDigestLog(): List<DigestLine> {
    val digestFile = File("logs") // Adjust path as needed
        .listFiles()
        ?.find { it.name.endsWith("_parsed_digest.jsonl") } ?: return emptyList()

    return digestFile.readLines().mapNotNull { line ->
        try {
            Json.decodeFromString<DigestLine>(line)
        } catch (_: Exception) {
            null
        }
    }
}

fun loadStackLog(context: Context): List<StackLogEntry> {
    val file = File(context.filesDir, LogType.STACK.filename)
    if (!file.exists()) return emptyList()

    return file.readLines().mapNotNull {
        try { Json.decodeFromString<StackLogEntry>(it) }
        catch (_: Exception) { null }
    }
}



@Composable
fun LogViewerScreen(context: Context, onNavToggle: () -> Unit) {
    var selectedLog by remember { mutableStateOf(LogType.DIGEST) }
    var logLines by remember { mutableStateOf(listOf("(loading...)")) }
    val digestLines = remember { loadDigestLog() }
    val stackLines = remember { loadStackLog(context) }


    LaunchedEffect(selectedLog) {
        val file = File(context.filesDir, selectedLog.filename)
        logLines = if (file.exists()) file.readLines() else listOf("(No entries found)")
    }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Log Viewer", style = MaterialTheme.typography.headlineSmall)
            TextButton(onClick = onNavToggle) { Text("Menu") }
        }

        Spacer(modifier = Modifier.height(12.dp))

        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Select Log:", modifier = Modifier.padding(end = 8.dp))
            var expanded by remember { mutableStateOf(false) }
            Box {
                Button(onClick = { expanded = true }) {
                    Text(selectedLog.displayName)
                }
                DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                    LogType.values().forEach { logType ->
                        DropdownMenuItem(
                            text = { Text(logType.displayName) },
                            onClick = {
                                selectedLog = logType
                                expanded = false
                            }
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        LazyColumn {
            when (selectedLog) {
                LogType.DIGEST -> {
                    item {
                        Text("Parsed Digest Log", style = MaterialTheme.typography.titleSmall)
                    }
                    items(digestLines) { line ->
                        Column(modifier = Modifier.padding(8.dp)) {
                            Text("Turn ${line.turn}", style = MaterialTheme.typography.labelSmall)
                            Text(line.text, style = MaterialTheme.typography.bodyMedium)
                            Text("Tags: ${line.tags.joinToString()}", style = MaterialTheme.typography.labelSmall)
                            Text("Score: ${line.score}", style = MaterialTheme.typography.labelSmall)
                            Divider()
                        }
                    }
                }

                LogType.STACK -> {
                    item {
                        Text("Narrator Stack Log", style = MaterialTheme.typography.titleSmall)
                    }
                    items(stackLines) { entry ->
                        Column(modifier = Modifier.padding(8.dp)) {
                            Text("Turn ${entry.turn} — ${entry.timestamp}", style = MaterialTheme.typography.labelMedium)
                            Text("Model: ${entry.model}", style = MaterialTheme.typography.labelSmall)
                            Text(
                                "Tokens: ${entry.token_summary.total} (in: ${entry.token_summary.input}, out: ${entry.token_summary.output})",
                                style = MaterialTheme.typography.labelSmall
                            )
                            Text("Latency: ${entry.latency_ms} ms", style = MaterialTheme.typography.labelSmall)

                            Spacer(Modifier.height(4.dp))
                            entry.stack.forEach { msg ->
                                Text("${msg.role.uppercase()}:", style = MaterialTheme.typography.labelSmall)
                                Text(msg.content, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(start = 8.dp))
                                Spacer(Modifier.height(2.dp))
                            }
                            Divider()
                        }
                    }
                }

                else -> {
                    item {
                        Text("${selectedLog.displayName} Raw Log", style = MaterialTheme.typography.titleSmall)
                    }
                    items(logLines) { line ->
                        Text(line, modifier = Modifier.padding(4.dp))
                    }
                }
            }
        }


    }
}
