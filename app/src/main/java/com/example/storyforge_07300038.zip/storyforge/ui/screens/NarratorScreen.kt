package com.example.storyforge.ui.screens

import android.util.Log
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.LocalIndication
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Casino
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.storyforge.StoryForgeViewModel
import com.example.storyforge.utils.DiceRoller
import kotlinx.coroutines.launch
import kotlinx.serialization.json.JsonElement
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.remember
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun NarratorScreen(
    viewModel: StoryForgeViewModel,
    onNavToggle: () -> Unit
) {
    val gameState by viewModel.gameState.collectAsState()
    val turnList by viewModel.turns.collectAsState()
    val worldChangeMessage by viewModel.worldChangeMessage.collectAsState()

    var inputText by remember { mutableStateOf("") }
    var currentRollFormula by remember { mutableStateOf("2d6") }
    var showRollDialog by remember { mutableStateOf(false) }

    val listState = rememberLazyListState()
    val coroutineScope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }

    // Automatically scroll to newest turn
    LaunchedEffect(turnList) {
        if (turnList.isNotEmpty()) {
            listState.animateScrollToItem(turnList.size - 1)
        }
    }

    // Trigger snackbar when worldChangeMessage appears
    LaunchedEffect(worldChangeMessage) {
        if (!worldChangeMessage.isNullOrBlank()) {
            snackbarHostState.showSnackbar(worldChangeMessage!!)
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {
            // Single header section
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Narrator", style = MaterialTheme.typography.bodyMedium)
                TextButton(onClick = onNavToggle) { Text("Menu") }
            }

            // Pinned items section
            PinnedItemsSection(viewModel)

            Spacer(modifier = Modifier.height(8.dp))
            // Narration history and floating dice
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
            ) {
                LazyColumn(
                    state = listState,
                    modifier = Modifier
                        .fillMaxSize()
                        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.2f))
                        .padding(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(turnList) { turn ->
                        Column(modifier = Modifier.fillMaxWidth()) {
                            Text(
                                "You: ${turn.action}",
                                color = MaterialTheme.colorScheme.onSurface,
                                style = MaterialTheme.typography.bodyMedium
                            )
                            if (turn.narration.isNotBlank()) {
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    "AI: ${turn.narration}",
                                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f),
                                    style = MaterialTheme.typography.bodyMedium
                                )
                            }
                        }
                    }
                }

                // Dice button overlay (unchanged)
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(8.dp)
                        .size(36.dp)
                        .background(
                            color = MaterialTheme.colorScheme.primary.copy(alpha = 0.15f),
                            shape = MaterialTheme.shapes.medium
                        )
                        .combinedClickable(
                            onClick = {
                                val result = DiceRoller.roll(currentRollFormula)
                                val summary = DiceRoller.format(result)
                                viewModel.processAction("Roll: $currentRollFormula\n$summary")
                            },
                            onLongClick = { showRollDialog = true }
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        Icons.Default.Casino,
                        contentDescription = "Roll Dice",
                        tint = MaterialTheme.colorScheme.primary
                    )
                }
            }

            // Input field with send icon (unchanged)
            OutlinedTextField(
                value = inputText,
                onValueChange = { inputText = it },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 4.dp),
                placeholder = {
                    Text(
                        "What do you do?",
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                    )
                },
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = MaterialTheme.colorScheme.surface,
                    unfocusedContainerColor = MaterialTheme.colorScheme.surface,
                    focusedTextColor = MaterialTheme.colorScheme.onSurface,
                    unfocusedTextColor = MaterialTheme.colorScheme.onSurface,
                    cursorColor = MaterialTheme.colorScheme.primary,
                    focusedIndicatorColor = MaterialTheme.colorScheme.primary,
                    unfocusedIndicatorColor = MaterialTheme.colorScheme.outline
                ),
                trailingIcon = {
                    IconButton(
                        onClick = {
                            if (inputText.isNotBlank()) {
                                viewModel.processAction(inputText)
                                inputText = ""
                                coroutineScope.launch {
                                    listState.animateScrollToItem(turnList.size)
                                }
                            }
                        }
                    ) {
                        Icon(
                            imageVector = Icons.Default.Send,
                            contentDescription = "Send",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            )
        }

        // World change snackbar (unchanged)
        SnackbarHost(
            hostState = snackbarHostState,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 16.dp)
        )

        // Roll formula dialog (unchanged)
        if (showRollDialog) {
            var input by remember { mutableStateOf(currentRollFormula) }

            AlertDialog(
                onDismissRequest = { showRollDialog = false },
                title = { Text("Set Dice Formula", color = MaterialTheme.colorScheme.onSurface) },
                text = {
                    OutlinedTextField(
                        value = input,
                        onValueChange = { input = it },
                        label = {
                            Text(
                                "e.g. 1d20+3 or 3d6",
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                            )
                        },
                        colors = TextFieldDefaults.colors(
                            focusedContainerColor = MaterialTheme.colorScheme.surface,
                            unfocusedContainerColor = MaterialTheme.colorScheme.surface,
                            focusedTextColor = MaterialTheme.colorScheme.onSurface,
                            unfocusedTextColor = MaterialTheme.colorScheme.onSurface
                        )
                    )
                },
                confirmButton = {
                    TextButton(
                        onClick = {
                            currentRollFormula = input
                            showRollDialog = false
                        }
                    ) {
                        Text("Set", color = MaterialTheme.colorScheme.primary)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showRollDialog = false }) {
                        Text("Cancel", color = MaterialTheme.colorScheme.onSurface)
                    }
                },
                containerColor = MaterialTheme.colorScheme.surface
            )
        }
    }
}

@Composable
fun PinnedItemsSection(viewModel: StoryForgeViewModel) {
    val gameState by viewModel.gameState.collectAsState()
    val pinnedKeys by viewModel.pinnedKeys.collectAsState()

    val flatWorld = flattenJsonObject(gameState.worldState)
    val pinnedItems = pinnedKeys.mapNotNull { key -> flatWorld[key]?.let { key to it } }

    if (pinnedItems.isNotEmpty()) {
        val grouped = pinnedItems
            .groupBy { it.first.substringBeforeLast(".") }
            .mapValues { entry ->
                entry.value.associate { it.first.substringAfterLast(".") to it.second }
            }

        FlowRow(
            modifier = Modifier.padding(4.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            grouped.forEach { (entityPath, attributes) ->
                val allKeys = attributes.keys.map { "$entityPath.$it" }

                Surface(
                    modifier = Modifier
                        .wrapContentSize()
                        .combinedClickable(
                            onClick = {},
                            onLongClick = {
                                viewModel.togglePin(entityPath)
                            }
                        ),
                    shape = RoundedCornerShape(6.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.2f)
                ) {
                    Column(
                        modifier = Modifier
                            .padding(horizontal = 6.dp, vertical = 4.dp)
                            .wrapContentWidth()
                    ) {
                        Text(
                            text = entityPath.split(".").last().replaceFirstChar { it.uppercase() },
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(Modifier.height(2.dp))
                        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            attributes.forEach { (label, value) ->
                                val fullKey = "$entityPath.$label"
                                MiniAttrRow(label = label, value = value) {
                                    viewModel.togglePin(fullKey)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}


@Composable
fun MiniAttrRow(label: String, value: JsonElement, onLongPress: () -> Unit) {
    val interactionSource = remember { MutableInteractionSource() }

    Surface(
        modifier = Modifier
            .wrapContentWidth()
            .combinedClickable(
                interactionSource = interactionSource,
                indication = LocalIndication.current,
                onClick = {},
                onLongClick = onLongPress
            ),
        shape = RoundedCornerShape(4.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.25f)
    ) {
        Row(
            modifier = Modifier
                .padding(horizontal = 4.dp, vertical = 1.dp), // ✅ minimal spacing
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "$label:",
                style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.width(1.dp)) // ✅ smaller gap
            Text(
                text = value.toString(),
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.primary
            )
        }
    }
}
