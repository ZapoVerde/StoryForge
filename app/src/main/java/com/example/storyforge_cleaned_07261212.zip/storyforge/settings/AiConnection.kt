package com.example.storyforge.settings

import kotlinx.serialization.Serializable

@Serializable
data class AiConnection(
    val id: String,                     // unique key (UUID or label)
    val displayName: String,           // shown in UI
    val description: String? = null,   // optional notes
    val apiUrl: String,                // endpoint
    val apiToken: String,              // auth token
    val functionCallingEnabled: Boolean = false, // ✅ NEW
    val dateAdded: Long,               // epoch millis
    val lastUpdated: Long,              // epoch millis
    //val modelName: String // REQUIRED, no default


)
