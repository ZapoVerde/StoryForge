package com.example.storyforge.settings

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.serialization.json.Json
import java.io.File
import java.util.UUID

object SettingsManager {
    private const val FILE_NAME = "settings.json"
    private val _settingsState = MutableStateFlow<Settings?>(null)
    val settingsState: StateFlow<Settings?> = _settingsState.asStateFlow()

    fun load(context: Context): Settings {
        val file = File(context.filesDir, FILE_NAME)
        val settings: Settings = if (!file.exists()) {
            val default = Settings(
                aiConnections = listOf(
                    AiConnection(
                        id = UUID.randomUUID().toString(),
                        displayName = "DeepSeek Default",
                        apiUrl = "https://api.deepseek.com/v1",
                        apiToken = "sk-1f09eb96ad704160ba57dd7a783d5c76",
                        functionCallingEnabled = true,
                        dateAdded = System.currentTimeMillis(),
                        lastUpdated = System.currentTimeMillis()
                    )
                )
            )
            saveSettings(context, default)
            default
        } else {
            val raw = file.readText()
            Json.decodeFromString(Settings.serializer(), raw)
        }

        _settingsState.value = settings
        return settings
    }

    fun update(context: Context, newSettings: Settings) {
        saveSettings(context, newSettings)
    }

    private fun saveSettings(context: Context, settings: Settings) {
        val file = File(context.filesDir, FILE_NAME)
        file.writeText(Json.encodeToString(Settings.serializer(), settings))
        _settingsState.value = settings
    }
}
