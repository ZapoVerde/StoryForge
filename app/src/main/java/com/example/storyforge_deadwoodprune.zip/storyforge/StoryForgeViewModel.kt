// file: com/example/storyforge/StoryForgeViewModel.kt
package com.example.storyforge

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.storyforge.core.Narrator
import com.example.storyforge.model.GameState
import com.example.storyforge.model.GameStateSlotStorage
import com.example.storyforge.model.GameStateStorage
import com.example.storyforge.prompt.PromptCard
import com.example.storyforge.prompt.PromptCardStorage
import com.example.storyforge.settings.Settings
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import android.content.Context
import android.util.Log
import com.example.storyforge.core.AINarrator
import com.example.storyforge.core.ChatCompletionRequest
import com.example.storyforge.core.DebugLogger
import com.example.storyforge.core.DummyNarrator
import com.example.storyforge.model.Message
import com.example.storyforge.prompt.AiSettings
import com.example.storyforge.ui.screens.flattenJsonObject
import kotlinx.serialization.json.*
import com.example.storyforge.core.NarrationParser
import com.example.storyforge.core.DigestManager
import com.example.storyforge.core.SceneManager
import com.example.storyforge.core.ensureEndsWithSlash
import com.example.storyforge.logging.NarrationLogger
import com.example.storyforge.model.WorldStateLog
import com.example.storyforge.model.TurnLog
import com.example.storyforge.model.DeltaInstruction
import com.example.storyforge.model.ConversationTurn
import com.example.storyforge.model.DigestLine
import com.example.storyforge.settings.AiConnection
import com.example.storyforge.stack.StackAssembler
import com.example.storyforge.stack.StackAssemblerInput
import com.example.storyforge.stack.StackInstructionsLoader
import com.example.storyforge.logging.TurnLogEntry
import com.example.storyforge.logging.LogViewMode
import com.example.storyforge.logging.TurnLogAssembler
import com.example.storyforge.model.StackLogEntry
import com.example.storyforge.model.TokenSummary
import com.example.storyforge.save.*
import java.time.Instant
import kotlinx.serialization.json.Json
import com.example.storyforge.save.readJsonLogLines
import java.io.File





data class Turn(val action: String, val narration: String)

class StoryForgeViewModel(
    private val narratorFactory: () -> Narrator,
    private val _settings: Settings,
    private val promptCardStorage: PromptCardStorage,
    val appContext: Context
) : ViewModel() {

    private val _gameState = MutableStateFlow(GameStateStorage.load(appContext))
    private val _promptCards = MutableStateFlow<List<PromptCard>>(emptyList())
    private val _errorMessage = MutableStateFlow<String?>(null)
    private val _isProcessing = MutableStateFlow(false)
    private val _worldChangeMessage = MutableStateFlow<String?>(null)
    private val _pinnedKeys = MutableStateFlow<Set<String>>(emptySet())
    private val _activePromptCard = MutableStateFlow<PromptCard?>(null)
    private val _useDummyNarrator = MutableStateFlow<Boolean>(false)
    private val _aiConnections = MutableStateFlow(_settings.aiConnections)
    private val _turnLogEntries = MutableStateFlow<List<TurnLogEntry>>(emptyList())
    private val _selectedLogViews = MutableStateFlow<List<LogViewMode>>(
        listOf(
            LogViewMode.RAW,
            LogViewMode.DIGEST,
            LogViewMode.DELTAS,
            LogViewMode.CONTEXT,
            LogViewMode.TOKENS,
            LogViewMode.SETTINGS,
            LogViewMode.ERRORS,
            LogViewMode.API
        )
    )
    private val _narratorUiState = MutableStateFlow(NarratorUiState())
    private val _turns = MutableStateFlow<List<ConversationTurn>>(emptyList())
    private val _stackLogs = MutableStateFlow<List<StackLogEntry>>(emptyList())

    val turns: StateFlow<List<ConversationTurn>> = _turns.asStateFlow()
    val stackLogs: StateFlow<List<StackLogEntry>> = _stackLogs.asStateFlow()
    val narratorUiState: StateFlow<NarratorUiState> = _narratorUiState.asStateFlow()
    val turnLogEntries: StateFlow<List<TurnLogEntry>> = _turnLogEntries.asStateFlow()
    val selectedLogViews: StateFlow<List<LogViewMode>> = _selectedLogViews.asStateFlow()
    val aiConnections: StateFlow<List<AiConnection>> = _aiConnections.asStateFlow()
    val activePromptCard: StateFlow<PromptCard?> = _activePromptCard.asStateFlow()
    val gameState: StateFlow<GameState> = _gameState.asStateFlow()
    val promptCards: StateFlow<List<PromptCard>> = _promptCards.asStateFlow()
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()
    val isProcessing: StateFlow<Boolean> = _isProcessing.asStateFlow()
    val worldChangeMessage: StateFlow<String?> = _worldChangeMessage.asStateFlow()
    val pinnedKeys: StateFlow<Set<String>> = _pinnedKeys.asStateFlow()
    val settings: Settings
        get() = _settings

    private fun buildSnapshot(): GameSnapshot {
        return GameSnapshot(
            promptCard = _activePromptCard.value!!,
            gameState = _gameState.value,
            turns = _turns.value,
            digestLines = DigestManager.getAllLines(),
            worldDeltas = WorldStateLog.readAll(appContext),
            turnLogs = _turnLogEntries.value,
            stackLogs = _stackLogs.value,
            sceneState = SceneManager.getSnapshot(),
            timestamp = Instant.now().toString(),
            narratorUiState = _narratorUiState.value,
        )
    }

    fun loadSnapshot(snapshot: GameSnapshot) {
        _activePromptCard.value = snapshot.promptCard
        _gameState.value = snapshot.gameState
        _turns.value = snapshot.turns
        _turnLogEntries.value = snapshot.turnLogs
        _narratorUiState.value = snapshot.narratorUiState
        _stackLogs.value = snapshot.stackLogs
        SceneManager.setFromSnapshot(snapshot.sceneState)
        DigestManager.setFromSnapshot(snapshot.digestLines)
        WorldStateLog.setAll(snapshot.worldDeltas)
    }

    fun appendStackLog(log: StackLogEntry) {
        _stackLogs.update { it + log }
    }

    fun clearStackLogs() {
        _stackLogs.value = emptyList()
    }

    fun updateAiConnections(newList: List<AiConnection>) {
        _aiConnections.value = newList
        // If you want to save it to disk, do that here:
        // SettingsManager.saveAiConnections(newList)
    }

    fun updateNarratorUiState(update: NarratorUiState) {
        _narratorUiState.value = update
    }

    fun appendTurnLog(entry: TurnLogEntry) {
        _turnLogEntries.update { current -> current + entry }
    }

    fun setSelectedLogViews(list: List<LogViewMode>) {
        _selectedLogViews.value = list
    }




    fun setUseDummyNarrator(enabled: Boolean) {
        _useDummyNarrator.value = enabled
    }

    fun isUsingDummyNarrator(): Boolean {
        return _useDummyNarrator.value
    }

    val useDummyNarrator: StateFlow<Boolean> = _useDummyNarrator.asStateFlow()

    init {
        _promptCards.value = promptCardStorage.loadDefaultsIfEmpty()

        viewModelScope.launch {
            _pinnedKeys.collect { keys ->
                Log.d("PIN_DEBUG", "Pinned keys updated: $keys")
            }
        }
    }

    fun setActivePromptCard(card: PromptCard) {
        // 🚫 Reject blank title
        if (card.title.trim().isEmpty()) {
            Log.w("PromptCard", "Refused to activate card — missing title")
            return
        }

        _activePromptCard.value = card

        val initBlock = card.worldStateInit.trim()
        if (initBlock.isNotBlank()) {
            try {
                val parsed = Json.parseToJsonElement(initBlock).jsonObject

                // ✅ Enforce 3-level world state structure
                val allValid = parsed.values.all { top ->
                    top is JsonObject && top.values.all { it is JsonObject }
                }

                if (!allValid) {
                    Log.w("PromptCard", "Refused to load worldStateInit — not a 3-level object")
                    return
                }

                _gameState.value = _gameState.value.copy(worldState = parsed)

            } catch (e: Exception) {
                Log.e("PromptCard", "Failed to parse structured worldStateInit", e)
            }
        }
    }



    fun addPromptCard(card: PromptCard) {
        _promptCards.update { current ->
            val updated = current.toMutableList()
            val index = updated.indexOfFirst { it.id == card.id }

            if (index != -1) {
                updated[index] = card  // ✅ update in-place
            } else {
                updated.add(card)      // ✅ append new
            }

            promptCardStorage.saveCards(updated)
            updated
        }
    }


    fun deletePromptCard(id: String) {
        _promptCards.update { current ->
            val updated = current.filterNot { it.id == id }
            promptCardStorage.saveCards(updated)
            updated
        }
    }

    fun togglePin(prefixKey: String) {
        Log.d("PIN_DEBUG", "Toggling pin for: $prefixKey")

        val flatWorld = flattenJsonObject(_gameState.value.worldState)
        val affectedKeys = flatWorld.keys.filter { it.startsWith(prefixKey) }

        if (affectedKeys.isEmpty()) {
            Log.w("PIN_DEBUG", "No keys matched for $prefixKey")
            return
        }

        val currentlyPinned = _pinnedKeys.value
        val isAdding = affectedKeys.any { it !in currentlyPinned }

        val newSet = if (isAdding) {
            currentlyPinned + affectedKeys
        } else {
            currentlyPinned - affectedKeys.toSet()
        }

        _pinnedKeys.value = newSet
        Log.d("PIN_DEBUG", "Updated pinned keys: $newSet")
    }

    private fun resolveNarrator(): Narrator {
        if (_useDummyNarrator.value) return DummyNarrator()

        val promptCard = _activePromptCard.value ?: return DummyNarrator()
        val connectionId = promptCard.aiSettings.selectedConnectionId
        val connection = _settings.aiConnections.find { it.id == connectionId }
        if (connection == null) {
            Log.w("Narrator", "No connection found for ID: $connectionId")
        }


        return try {
            if (connection == null || !connection.apiUrl.trim().startsWith("http")) {
                DummyNarrator()
            } else {
                AINarrator.fromConnection(connection)
            }
        } catch (e: Exception) {
            DummyNarrator()
        }
    }

    fun processAction(action: String) {
        if (action.isBlank()) {
            _errorMessage.value = "Action cannot be empty"
            return
        }

        val sendTurnId = _turns.value.size
        _turns.value += ConversationTurn(user = action, narrator = "")

        viewModelScope.launch {
            _isProcessing.value = true
            _errorMessage.value = null

            val narrator = resolveNarrator()
            val promptCard = _activePromptCard.value ?: return@launch
            val connectionId = promptCard.aiSettings.selectedConnectionId
            val connection = _settings.aiConnections.find { it.id == connectionId }
            if (connection == null) {
                _errorMessage.value = "No AI connection found"
                _isProcessing.value = false
                return@launch
            }

            val stackInput = StackAssemblerInput(
                turnNumber = sendTurnId,
                userMessage = action,
                stackInstructions = StackInstructionsLoader.fromJson(promptCard.stackInstructions),
                aiPrompt = promptCard.prompt,
                emitSkeleton = promptCard.emitSkeleton,
                gameRules = promptCard.gameRules,
                firstTurnOnlyBlock = promptCard.firstTurnOnlyBlock,
                turnHistory = _turns.value.map { ConversationTurn(it.user, it.narrator) },
                digestLines = DigestManager.getAllLines(),
                expressionLog = emptyMap(),
                worldState = _gameState.value.worldState,
                sceneTags = SceneManager.getSceneTags(_gameState.value.worldState).toSet()
            )

            val assembledMessages = StackAssembler.assemble(stackInput)

            // --- Write log entry for turn N (SEND) ---
            val request = ChatCompletionRequest(
                model = connection.modelSlug,
                messages = assembledMessages,
                temperature = promptCard.aiSettings.temperature,
                top_p = promptCard.aiSettings.topP,
                max_tokens = promptCard.aiSettings.maxTokens,
                presence_penalty = promptCard.aiSettings.presencePenalty,
                frequency_penalty = promptCard.aiSettings.frequencyPenalty,
                stream = false
            )
            _stackLogs.update { it + StackLogEntry(
                turn = sendTurnId,
                timestamp = Instant.now().toString(),
                model = connection.modelSlug,
                stack = assembledMessages,
                token_summary = TokenSummary(
                    input = assembledMessages.sumOf { it.content.length / 4 },
                    output = promptCard.aiSettings.maxTokens,
                    total = assembledMessages.sumOf { it.content.length / 4 } + promptCard.aiSettings.maxTokens
                ),
                latency_ms = 0L // updated later if needed
            ) }


            val requestJson = Json.encodeToString(request.copy(messages = emptyList()))

            val apiUrl = connection.apiUrl.trim().ensureEndsWithSlash() + "chat/completions"

            val preLogEntry = TurnLogAssembler.assemble(
                turnNumber = sendTurnId,
                userInput = action,
                rawNarratorOutput = "",
                parsedDigest = null,
                parsedDeltas = null,
                contextSnapshot = assembledMessages.joinToString("\n\n") { "${it.role}: ${it.content}" },
                tokenUsage = null,
                aiSettings = promptCard.aiSettings,
                errorFlags = emptyList(),
                apiRequestBody = requestJson,
                apiResponseBody = "",
                apiUrl = apiUrl,
                latencyMs = 0L,
                modelSlugUsed = connection.modelSlug
            )
            appendTurnLog(preLogEntry)

            // --- Now make API call ---
            val requestForLog = narrator.generateFull(
                messages = assembledMessages,
                settings = promptCard.aiSettings,
                modelName = connection.modelName,
                turnId = sendTurnId,
                context = appContext
            )

            requestForLog.onSuccess { narratorResult ->
                val narration = narratorResult.narration
                val deltas = narratorResult.deltas

                val taggedDeltas = deltas.mapValues { (key, instruction) ->
                    if (instruction is DeltaInstruction.Declare) {
                        val pathParts = instruction.key.split(".")
                        if (pathParts.size >= 2) {
                            val (category, _) = pathParts
                            val valueObj = instruction.value as? JsonObject ?: return@mapValues instruction
                            if (!valueObj.containsKey("tag")) {
                                val inferredTag = when (category) {
                                    "npcs", "entities" -> "character"
                                    "locations", "places" -> "location"
                                    else -> null
                                }
                                if (inferredTag != null) {
                                    val patched = valueObj.toMutableMap()
                                    patched["tag"] = JsonPrimitive(inferredTag)
                                    return@mapValues DeltaInstruction.Declare(instruction.key, JsonObject(patched))
                                }
                            }
                        }
                    }
                    instruction
                }

                val enrichedProse = narration
                _turns.value += ConversationTurn(user = "", narrator = enrichedProse)



                _gameState.value.applyDeltas(taggedDeltas)
                WorldStateLog.append(appContext, sendTurnId + 1, taggedDeltas)
                // Save snapshot after turn resolves
                val snapshot = buildSnapshot()
                GameStateStorage.saveSnapshot(appContext, snapshot)

                val parsed = NarrationParser.extractJsonAndCleanNarration(narration)
                val digest = parsed.digestLines.firstOrNull() // may be null

                val receiveLog = TurnLogAssembler.assemble(
                    turnNumber = sendTurnId + 1,
                    userInput = "",
                    rawNarratorOutput = enrichedProse,
                    parsedDigest = digest?.let { listOf(it) },
                    parsedDeltas = deltas,
                    contextSnapshot = null,
                    tokenUsage = null,
                    aiSettings = promptCard.aiSettings,
                    errorFlags = emptyList(),
                    apiRequestBody = "",
                    apiResponseBody = narratorResult.apiResponseBody,
                    apiUrl = narratorResult.apiUrl,
                    latencyMs = narratorResult.latencyMs,
                    modelSlugUsed = narratorResult.modelSlugUsed
                )
                appendTurnLog(receiveLog)

            }.onFailure { ex ->
                _errorMessage.value = "Narration failed: ${ex.localizedMessage}"
                ex.printStackTrace()
            }

            _isProcessing.value = false
        }
    }


    fun GameState.buildMessageList(action: String): List<Message> {
        val priorTurns = turns.value

        val history = priorTurns.flatMap {
            listOf(
                Message(role = "user", content = it.user),
                Message(role = "assistant", content = it.narrator)
            )
        }

        return history + Message(role = "user", content = action)
    }

    fun clearError() {
        _errorMessage.value = null
    }

    fun saveToSlot(promptCardName: String) {
        GameStateSlotStorage.saveSlot(appContext, _gameState.value, promptCardName)
    }

    fun resetSession(newState: GameState = GameState()) {
        _gameState.value = newState
        _turns.value = emptyList()
        _errorMessage.value = null
        _isProcessing.value = false
    }

    fun deleteWorldCategory(category: String) {
        val updated = _gameState.value.worldState.toMutableMap()
        updated.remove(category)
        _gameState.value = _gameState.value.copy(worldState = JsonObject(updated))
        GameStateStorage.save(appContext, _gameState.value)
    }

    fun deleteWorldKey(fullKey: String) {
        val segments = fullKey.split(".")
        if (segments.size < 2) return

        val updated = _gameState.value.worldState.toMutableMap()
        val worldObj = updated["world"]?.jsonObject?.toMutableMap() ?: return

        val flagKey = segments.drop(1).joinToString(".")
        worldObj.remove(flagKey)
        updated["world"] = JsonObject(worldObj)

        val newWorldState = JsonObject(updated)
        _gameState.value = _gameState.value.copy(worldState = newWorldState)
        GameStateStorage.save(appContext, _gameState.value)
    }

    fun editWorldKey(fullKey: String, newValue: JsonElement) {
        val segments = fullKey.split(".")
        if (segments.isEmpty()) return

        val original = _gameState.value.worldState
        val updated = original.toMutableMap()
        var current: MutableMap<String, JsonElement> = updated

        for (i in 0 until segments.size - 1) {
            val obj = current[segments[i]] as? JsonObject ?: return
            val next = obj.toMutableMap()
            current[segments[i]] = JsonObject(next)
            current = next
        }

        current[segments.last()] = newValue
        val newWorldState = JsonObject(updated)
        _gameState.value = _gameState.value.copy(worldState = newWorldState)
        GameStateStorage.save(appContext, _gameState.value)
    }

    fun deleteEntity(category: String, entity: String, level: Int = 2) {
        val world = _gameState.value.worldState.toMutableMap()

        if (level == 2) {
            val entities = world["entities"]?.jsonObject?.toMutableMap() ?: return
            val entityType = entities[category]?.jsonObject?.toMutableMap() ?: return

            entityType.remove(entity)
            entities[category] = JsonObject(entityType)
            world["entities"] = JsonObject(entities)
        } else if (level == 1) {
            val cat = world[category]?.jsonObject?.toMutableMap() ?: return
            cat.remove(entity)
            world[category] = JsonObject(cat)
        } else {
            return
        }

        _gameState.value = _gameState.value.copy(worldState = JsonObject(world))
        GameStateStorage.save(appContext, _gameState.value)
    }

    fun renameEntity(category: String, oldName: String, newName: String) {
        if (oldName == newName || newName.isBlank()) return

        val world = _gameState.value.worldState.toMutableMap()
        val categoryMap = world[category]?.jsonObject?.toMutableMap() ?: return
        val oldEntity = categoryMap[oldName] ?: return

        if (categoryMap.containsKey(newName)) return

        categoryMap.remove(oldName)
        categoryMap[newName] = oldEntity
        world[category] = JsonObject(categoryMap)
        val updatedState = _gameState.value.copy(worldState = JsonObject(world))
        _gameState.value = updatedState

        val oldPrefix = "$category.$oldName."
        val newPrefix = "$category.$newName."

        _pinnedKeys.update { current ->
            current.map {
                if (it.startsWith(oldPrefix)) newPrefix + it.removePrefix(oldPrefix) else it
            }.toSet()
        }

        GameStateStorage.save(appContext, updatedState)
    }

    fun renameCategory(oldName: String, newName: String) {
        if (oldName == newName || newName.isBlank()) return

        val world = _gameState.value.worldState.toMutableMap()
        if (!world.containsKey(oldName) || world.containsKey(newName)) return

        val oldValue = world[oldName] ?: return
        world.remove(oldName)
        world[newName] = oldValue

        val updatedState = _gameState.value.copy(worldState = JsonObject(world))
        _gameState.value = updatedState

        val oldPrefix = "$oldName."
        val newPrefix = "$newName."

        _pinnedKeys.update { keys ->
            keys.map { key ->
                if (key.startsWith(oldPrefix)) newPrefix + key.removePrefix(oldPrefix) else key
            }.toSet()
        }

        GameStateStorage.save(appContext, updatedState)
    }
}
