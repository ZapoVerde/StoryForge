package com.example.storyforge.ui.screens

import android.util.Log
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.storyforge.StoryForgeViewModel
import com.example.storyforge.prompt.PromptCard
import com.example.storyforge.settings.AiConnection
import com.example.storyforge.settings.Settings
import java.util.UUID

sealed class PromptCardUIState {
    object None : PromptCardUIState()
    data class Editing(val card: PromptCard) : PromptCardUIState()
    object Loading : PromptCardUIState()
}

@Composable
fun PromptCardScreen(
    viewModel: StoryForgeViewModel,
    onNavToggle: () -> Unit,
    navController: NavController,
    availableConnections: List<AiConnection>,
    currentSettings: Settings
) {
    val cards by viewModel.promptCards.collectAsState()
    var uiState by remember { mutableStateOf<PromptCardUIState>(PromptCardUIState.None) }

    when (val state = uiState) {
        is PromptCardUIState.None -> {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("Prompt Cards", style = MaterialTheme.typography.headlineMedium)

                Button(onClick = {
                    val newCard = PromptCard(
                        id = UUID.randomUUID().toString(),
                        title = "",
                        prompt = "",
                        connectionId = availableConnections.firstOrNull()?.id // ✅ default to first available
                    )
                    uiState = PromptCardUIState.Editing(newCard)
                }) {
                    Text("Create New")
                }

                Button(onClick = {
                    uiState = PromptCardUIState.Loading
                }) {
                    Text("Load Existing")
                }

                TextButton(onClick = onNavToggle) {
                    Text("Menu")
                }
            }
        }

        is PromptCardUIState.Editing -> {
            var unsavedChanges by remember { mutableStateOf(false) }
            var editedCard by remember { mutableStateOf(state.card) }

            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    PromptCardEditor(
                        card = editedCard,
                        onDirtyChange = { unsavedChanges = it },
                        onCardChange = { newCard ->
                            editedCard = newCard
                        },
                        availableConnections = availableConnections,
                        selectedConnectionId = editedCard.connectionId,
                        onConnectionSelected = { connectionId ->
                            editedCard = editedCard.copy(connectionId = connectionId)
                            unsavedChanges = true
                        }
                    )
                }
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Button(
                            onClick = {
                                viewModel.addPromptCard(editedCard)
                                unsavedChanges = false
                                uiState = PromptCardUIState.None
                            },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Save")
                        }

                        Button(
                            onClick = {
                                viewModel.resetSession()
                                viewModel.processAction(editedCard.prompt)
                                try {
                                    viewModel.saveToSlot(editedCard.title)
                                } catch (e: Exception) {
                                    Log.e("PromptCard", "Failed to save slot", e)
                                }
                                navController.navigate("narrator")
                            },
                            enabled = !unsavedChanges && editedCard.connectionId != null,
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Fire")
                        }

                        Button(
                            onClick = {
                                if (unsavedChanges) {
                                    // Show confirmation dialog
                                } else {
                                    uiState = PromptCardUIState.None
                                }
                            },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Cancel")
                        }
                    }
                }
            }
        }

        is PromptCardUIState.Loading -> {
            PromptCardLoadList(
                cards = cards,
                onLoad = { card ->
                    uiState = PromptCardUIState.Editing(card)
                },
                onClone = { card ->
                    val newCard = card.copy(
                        id = UUID.randomUUID().toString(),
                        title = "${card.title} (Copy)"
                    )
                    viewModel.addPromptCard(newCard)
                    uiState = PromptCardUIState.Editing(newCard)
                },
                onCancel = { uiState = PromptCardUIState.None }
            )
        }
    }
}

@Composable
fun ConnectionDropdown(
    selectedConnectionId: String?,
    availableConnections: List<AiConnection>,
    onConnectionSelected: (String) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }
    val selected = availableConnections.find { it.id == selectedConnectionId }

    Box(modifier = Modifier.fillMaxWidth()) {
        OutlinedButton(
            onClick = { expanded = true },
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(text = selected?.let { "${it.displayName} – ${it.modelName}" } ?: "Select Connection")

                Icon(
                    imageVector = Icons.Default.ArrowDropDown,
                    contentDescription = "Expand"
                )
            }
        }


        DropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false },
            modifier = Modifier.fillMaxWidth()
        ) {
            availableConnections.forEach { connection ->
                DropdownMenuItem(
                    text = { Text("${connection.displayName} – ${connection.modelName}") },
                    onClick = {
                        expanded = false
                        onConnectionSelected(connection.id)
                    }
                )
            }
        }
    }
}


@Composable
fun PromptCardLoadList(
    cards: List<PromptCard>,
    onLoad: (PromptCard) -> Unit,
    onClone: (PromptCard) -> Unit,
    onCancel: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text("Load Prompt Card", style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(8.dp))

        LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(cards) { card ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
                ) {
                    Column(Modifier.padding(12.dp)) {
                        Text(card.title, style = MaterialTheme.typography.titleMedium)
                        card.description?.let {
                            Text(it, style = MaterialTheme.typography.bodySmall)
                        }

                        card.connectionId?.let {
                            Text(
                                text = "API: ${card.connectionId}",
                                style = MaterialTheme.typography.labelSmall
                            )
                        }

                        Spacer(Modifier.height(8.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Button(onClick = { onLoad(card) }) {
                                Text("Load")
                            }
                            Button(onClick = { onClone(card) }) {
                                Text("Clone")
                            }
                        }
                    }
                }
            }
        }

        Spacer(Modifier.height(16.dp))

        Button(
            onClick = onCancel,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Back")
        }
    }
}