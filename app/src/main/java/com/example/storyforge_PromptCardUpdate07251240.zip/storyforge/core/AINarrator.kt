package com.example.storyforge.core

import android.util.Log
import com.example.storyforge.model.DeltaInstruction
import com.example.storyforge.model.GameState
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.Body
import retrofit2.http.Header
import retrofit2.http.POST
import java.util.concurrent.TimeUnit

// --- Retrofit API Definition ---
internal interface AINarratorApiService {
    @POST("chat/completions")
    suspend fun generateNarration(
        @Header("Authorization") auth: String,
        @Body request: ChatCompletionRequest
    ): ChatCompletionResponse
}

// --- Data Models for DeepSeek / OpenAI Format ---
internal data class ChatCompletionRequest(
    val model: String = "deepseek-chat",
    val messages: List<Message>,
    val stream: Boolean = false
)

internal data class Message(
    val role: String,
    val content: String
)

internal data class ChatCompletionResponse(
    val choices: List<Choice>
)

internal data class Choice(
    val message: Message
)

// --- Main API Client ---
class AINarrator private constructor(
    private val apiService: AINarratorApiService,
    private val apiKey: String,
    private val isDebug: Boolean
) : Narrator {
    override suspend fun generate(
        action: String,
        state: GameState
    ): Result<Pair<String, Map<String, DeltaInstruction>>> {

        if (apiKey == "MISSING_API_KEY") {
            return Result.failure(IllegalStateException("API key not configured"))
        }

        val sanitizedAction = action.take(200).trim()
        if (sanitizedAction.isEmpty()) {
            return Result.failure(IllegalArgumentException("Empty action"))
        }

        return try {
            val stateSummary = buildStateSummary(state)

            val messages = listOf(
                Message("system", "You are a helpful narrator AI for a fantasy game. Respond only with narration and nothing else."),
                Message("user", "$sanitizedAction\n\nGame state:\n$stateSummary")
            )

            val request = ChatCompletionRequest(messages = messages)

            val response = apiService.generateNarration(
                auth = "Bearer $apiKey",
                request = request
            )

            val raw = response.choices.firstOrNull()?.message?.content?.trim()
                ?: return Result.failure(Exception("Empty response from API"))

            val (narration, deltas) = NarrationParser.extractJsonAndCleanNarration(raw)
            NarrationParser.logDeltas(deltas)

            Result.success(narration to deltas)

        } catch (ex: Exception) {
            Log.e("AINarrator", "API call failed", ex)
            Result.failure(Exception("Network error: ${ex.localizedMessage}"))
        }
    }

    private fun buildStateSummary(state: GameState): String {
        val sb = StringBuilder()
        sb.append("HP: ${state.hp}\n")
        sb.append("Gold: ${state.gold}\n")

        if (state.worldState.isNotEmpty()) {
            sb.append("World:\n")
            state.worldState.entries.forEach { (key, value) ->
                sb.append("- $key: $value\n")
            }
        }

        return sb.toString()
    }


    companion object {
        fun create(
            apiKey: String = "MISSING_API_KEY",
            isDebug: Boolean = false,
            baseUrl: String = "https://api.deepseek.com/v1/"
        ): AINarrator {
            val client = OkHttpClient.Builder()
                .connectTimeout(30, TimeUnit.SECONDS)
                .readTimeout(30, TimeUnit.SECONDS)
                .writeTimeout(30, TimeUnit.SECONDS)
                .addInterceptor(HttpLoggingInterceptor().apply {
                    level = if (isDebug) {
                        HttpLoggingInterceptor.Level.BODY
                    } else {
                        HttpLoggingInterceptor.Level.NONE
                    }
                })
                .build()

            val retrofit = Retrofit.Builder()
                .baseUrl(baseUrl)
                .client(client)
                .addConverterFactory(GsonConverterFactory.create())
                .build()

            return AINarrator(
                apiService = retrofit.create(AINarratorApiService::class.java),
                apiKey = apiKey,
                isDebug = isDebug
            )
        }
    }
}
