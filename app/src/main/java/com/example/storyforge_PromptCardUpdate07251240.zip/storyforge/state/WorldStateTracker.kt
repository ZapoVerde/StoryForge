package com.example.storyforge.state

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonNull
import kotlinx.serialization.json.JsonObject

class WorldStateTracker {

    // --- Internal backing state ---
    private val _pinnedKeys = MutableStateFlow<Set<String>>(emptySet())
    private val _pinnedCategories = MutableStateFlow<Set<String>>(emptySet())

    // --- Exposed public state ---
    val pinnedKeys: StateFlow<Set<String>> = _pinnedKeys
    val pinnedCategories: StateFlow<Set<String>> = _pinnedCategories

    // --- Resolution layer ---
    fun getEffectivePinnedKeys(world: JsonObject): Set<String> {
        val all = _pinnedKeys.value.toMutableSet()
        _pinnedCategories.value.forEach { category ->
            flattenJsonObject(world).forEach { (key, value) ->
                if (key.startsWith("$category.") && value !is JsonNull) {
                    all.add(key)
                }
            }
        }
        return all
    }

    fun isKeyPinned(key: String, world: JsonObject): Boolean {
        return getEffectivePinnedKeys(world).contains(key)
    }

    fun isEntityPinned(category: String, entity: String, world: JsonObject): Boolean {
        val prefix = "$category.$entity."
        return flattenJsonObject(world)
            .filter { it.key.startsWith(prefix) }
            .all { isKeyPinned(it.key, world) }
    }

    fun isCategoryPinned(category: String): Boolean {
        return _pinnedCategories.value.contains(category)
    }

    // --- Actions ---
    fun toggleKey(key: String) {
        _pinnedKeys.update { current ->
            if (current.contains(key)) current - key else current + key
        }
    }

    fun toggleEntity(category: String, entity: String, world: JsonObject) {
        val prefix = "$category.$entity."
        val keys = flattenJsonObject(world)
            .filter { it.key.startsWith(prefix) }
            .map { it.key }
            .toSet()

        val allPinned = keys.all { _pinnedKeys.value.contains(it) }
        _pinnedKeys.update { current ->
            if (allPinned) current - keys else current + keys
        }
    }

    fun toggleCategory(category: String) {
        _pinnedCategories.update { current ->
            if (current.contains(category)) current - category else current + category
        }
    }

    fun observeEffectiveItems(world: JsonObject): StateFlow<List<Pair<String, JsonElement>>> {
        val result = MutableStateFlow<List<Pair<String, JsonElement>>>(emptyList())
        val keys = getEffectivePinnedKeys(world)
        val values = keys.mapNotNull { key ->
            findValueInJson(world, key)?.let { key to it }
        }
        result.value = values
        return result
    }

    // --- Helpers ---
    private fun findValueInJson(json: JsonObject, fullKey: String): JsonElement? {
        val parts = fullKey.split(".")
        var current: JsonElement = json
        for (part in parts) {
            current = (current as? JsonObject)?.get(part) ?: return null
        }
        return current
    }

    private fun flattenJsonObject(obj: JsonObject, prefix: String = ""): Map<String, JsonElement> {
        val result = mutableMapOf<String, JsonElement>()
        for ((k, v) in obj) {
            val fullKey = if (prefix.isEmpty()) k else "$prefix.$k"
            when (v) {
                is JsonObject -> result.putAll(flattenJsonObject(v, fullKey))
                else -> result[fullKey] = v
            }
        }
        return result
    }
}
