package com.example.storyforge

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp

@Composable
fun StoryForgeApp(viewModel: StoryForgeViewModel) {
    var actionText by remember { mutableStateOf("") }
    val gameState by viewModel.gameState.collectAsState()
    val errorMessage by viewModel.errorMessage.collectAsState()
    val keyboardController = LocalSoftwareKeyboardController.current

    // Error Dialog
    if (errorMessage != null) {
        AlertDialog(
            onDismissRequest = { viewModel.clearError() },
            title = { Text("Error") },
            text = { Text(errorMessage!!) },
            confirmButton = {
                Button(onClick = { viewModel.clearError() }) {
                    Text("OK")
                }
            }
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        // Game Content
        Column(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(gameState.narration)
            HorizontalDivider()
            Row(Modifier.fillMaxWidth()) {
                Text("HP: ${gameState.hp}")
                Text("Gold: ${gameState.gold}")
            }
        }

        // Input Section
        Column {
            OutlinedTextField(
                value = actionText,
                onValueChange = { actionText = it },
                label = { Text("Your action") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                keyboardActions = KeyboardActions(
                    onDone = {
                        viewModel.processAction(actionText)
                        actionText = ""
                        keyboardController?.hide()
                    }
                ),
                isError = errorMessage != null
            )

            Spacer(Modifier.height(8.dp))

            Button(
                onClick = {
                    viewModel.processAction(actionText)
                    actionText = ""
                    keyboardController?.hide()
                },
                modifier = Modifier.fillMaxWidth(),
                enabled = actionText.isNotBlank()
            ) {
                Text("Submit Action")
            }
        }
    }
}