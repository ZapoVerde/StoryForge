package com.example.storyforge.core

import com.example.storyforge.model.DeltaInstruction
import com.example.storyforge.model.GameState

interface Narrator {
    suspend fun generate(
        action: String,
        state: GameState
    ): Result<Pair<String, Map<String, DeltaInstruction>>>
}
