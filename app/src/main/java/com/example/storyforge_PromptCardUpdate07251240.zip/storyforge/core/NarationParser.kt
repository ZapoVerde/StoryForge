package com.example.storyforge.core

import android.util.Log
import com.example.storyforge.model.DeltaInstruction
import com.example.storyforge.model.WorldStateLog
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.jsonObject
import java.time.Instant

object NarrationParser {

    private val jsonStartRegex = Regex("```json|---")

    fun extractJsonAndCleanNarration(raw: String): Pair<String, Map<String, DeltaInstruction>> {
        Log.d("NarrationParser", "Raw input: $raw")

        val parts = raw.split(jsonStartRegex)
        if (parts.size < 2) {
            Log.w("NarrationParser", "No JSON block found in narration.")
            return raw to emptyMap()
        }

        val narration = parts[0].trim()
        val jsonRaw = parts[1].trim().removeSuffix("```").trim()

        Log.d("NarrationParser", "Extracted narration: $narration")
        Log.d("NarrationParser", "Extracted JSON block: $jsonRaw")

        return try {
            val json = Json.parseToJsonElement(jsonRaw).jsonObject
            val parsed = parseDeltas(json)
            Log.d("NarrationParser", "Parsed delta keys: ${parsed.keys}")
            narration to parsed
        } catch (e: Exception) {
            Log.e("NarrationParser", "Failed to parse delta JSON", e)
            raw to emptyMap()
        }
    }


    private fun parseDeltas(json: JsonObject): Map<String, DeltaInstruction> {
        return json.mapNotNull { (rawKey, value) ->
            try {
                val op = rawKey.first()
                val key = rawKey.drop(1)

                val (target, variable) = key.split(".", limit = 2).let {
                    if (it.size < 2) return@mapNotNull null
                    it[0] to it[1]
                }

                when (op) {
                    '+' -> key to DeltaInstruction.Add(variable, value)
                    '=' -> key to DeltaInstruction.Assign(variable, value)
                    '!' -> key to DeltaInstruction.Declare(variable, value)
                    '-' -> key to DeltaInstruction.Delete(variable)
                    else -> null
                }
            } catch (_: Exception) {
                null
            }
        }.toMap()
    }


    fun logDeltas(deltas: Map<String, DeltaInstruction>) {
        val timestamp = Instant.now().toString()
        val entry = mapOf("timestamp" to timestamp, "changes" to deltas.mapValues { it.value.toLogValue() })
        WorldStateLog.append(entry)
    }
}
