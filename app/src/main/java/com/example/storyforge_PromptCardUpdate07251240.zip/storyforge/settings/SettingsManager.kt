package com.example.storyforge.settings

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import java.io.File


object SettingsManager {
    private const val FILE_NAME = "settings.json"
    private val _settingsState = MutableStateFlow<Settings?>(null)
    val settingsState: StateFlow<Settings?> = _settingsState.asStateFlow()

    fun load(context: Context): Settings {
        val file = File(context.filesDir, FILE_NAME)
        return if (!file.exists()) {
            val default = Settings()
            saveSettings(context, default)
            default
        } else {
            val raw = file.readText()
            Json.decodeFromString(Settings.serializer(), raw)
        }
    }

    fun update(context: Context, newSettings: Settings) {
        saveSettings(context, newSettings)
    }

    private fun saveSettings(context: Context, settings: Settings) {
        val file = File(context.filesDir, FILE_NAME)
        file.writeText(Json.encodeToString(Settings.serializer(), settings))
        _settingsState.value = settings
    }
}