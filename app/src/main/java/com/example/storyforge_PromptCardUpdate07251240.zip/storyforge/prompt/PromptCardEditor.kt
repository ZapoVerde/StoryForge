package com.example.storyforge.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.storyforge.prompt.PromptCard
import java.util.*
import androidx.compose.ui.Alignment
import com.example.storyforge.prompt.AiSettings

@Composable
fun PromptCardEditor(
    card: PromptCard?,
    onSave: (PromptCard) -> Unit,
    onCancel: () -> Unit,
    onDirtyChange: (Boolean) -> Unit,
    onCardChange: (PromptCard) -> Unit
)
 {
    var title by remember { mutableStateOf(card?.title ?: "") }
    var description by remember { mutableStateOf(card?.description ?: "") }
    var prompt by remember { mutableStateOf(card?.prompt ?: "") }
    var emitSkeleton by remember { mutableStateOf(card?.emitSkeleton ?: "") }
    var worldState by remember { mutableStateOf(card?.worldStateInit ?: "") }
    var gameRules by remember { mutableStateOf(card?.gameRules ?: "") }
    var aiSettings by remember { mutableStateOf(card?.aiSettings ?: AiSettings()) }

    val currentCard = PromptCard(
        id = card?.id ?: UUID.randomUUID().toString(),
        title = title,
        description = description.ifBlank { null },
        prompt = prompt,
        emitSkeleton = emitSkeleton,
        worldStateInit = worldState,
        gameRules = gameRules,
        aiSettings = aiSettings
    )

    // Compare with original and report dirty state
    LaunchedEffect(currentCard) {
        if (card != null) {
            onDirtyChange(currentCard != card)
            onCardChange(currentCard)
        }
    }



    Column(modifier = Modifier.fillMaxWidth().padding(8.dp)) {
        TitleSection(title, description, onTitleChange = { title = it }, onDescriptionChange = { description = it })
        AiPromptSection(prompt, onPromptChange = { prompt = it })
        EmitRulesSection(emitSkeleton, onEmitChange = { emitSkeleton = it })
        WorldStateSection(worldState, onWorldStateChange = { worldState = it })
        GameRulesSection(gameRules, onRulesChange = { gameRules = it })
        AiSettingsSection(aiSettings, onSettingsChange = { aiSettings = it })

        Spacer(Modifier.height(12.dp))
    }
}

@Composable
fun CollapsibleSection(
    title: String,
    initiallyExpanded: Boolean = false,
    content: @Composable ColumnScope.() -> Unit
) {
    var expanded by rememberSaveable { mutableStateOf(initiallyExpanded) }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        elevation = CardDefaults.cardElevation(4.dp)
    ) {
        Column(modifier = Modifier.padding(8.dp)) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { expanded = !expanded },
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(title, style = MaterialTheme.typography.titleMedium)
                Icon(
                    imageVector = if (expanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                    contentDescription = null
                )
            }

            if (expanded) {
                Spacer(Modifier.height(8.dp))
                content()
            }
        }
    }
}

@Composable
fun TitleSection(
    title: String,
    description: String,
    onTitleChange: (String) -> Unit,
    onDescriptionChange: (String) -> Unit
) {
    CollapsibleSection("Title & Description", initiallyExpanded = true) {
        OutlinedTextField(
            value = title,
            onValueChange = onTitleChange,
            label = { Text("Title") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = description,
            onValueChange = onDescriptionChange,
            label = { Text("Description") },
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 8.dp)
        )
    }
}

@Composable
fun AiPromptSection(prompt: String, onPromptChange: (String) -> Unit) {
    CollapsibleSection("AI Prompt", initiallyExpanded = true) {
        OutlinedTextField(
            value = prompt,
            onValueChange = onPromptChange,
            label = { Text("AI Prompt") },
            modifier = Modifier
                .fillMaxWidth()
                .height(140.dp)
        )
    }
}

@Composable
fun EmitRulesSection(emit: String, onEmitChange: (String) -> Unit) {
    CollapsibleSection("Emit & Tagging Skeleton") {
        OutlinedTextField(
            value = emit,
            onValueChange = onEmitChange,
            label = { Text("Emit/Tagging Rules") },
            modifier = Modifier
                .fillMaxWidth()
                .height(140.dp)
        )
    }
}

@Composable
fun WorldStateSection(worldState: String, onWorldStateChange: (String) -> Unit) {
    CollapsibleSection("World State Initialization") {
        OutlinedTextField(
            value = worldState,
            onValueChange = onWorldStateChange,
            label = { Text("Initial World State") },
            modifier = Modifier
                .fillMaxWidth()
                .height(140.dp)
        )
    }
}

@Composable
fun GameRulesSection(rules: String, onRulesChange: (String) -> Unit) {
    CollapsibleSection("Game Rules Skeleton") {
        OutlinedTextField(
            value = rules,
            onValueChange = onRulesChange,
            label = { Text("Game Rules") },
            modifier = Modifier
                .fillMaxWidth()
                .height(140.dp)
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AiSettingsSection(
    settings: AiSettings,
    onSettingsChange: (AiSettings) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }

    CollapsibleSection("AI Settings", initiallyExpanded = true) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text("Model: ${settings.modelName}")
            Text("Temp: ${settings.temperature}")
            Text("Tokens: ${settings.maxTokens}")
            TextButton(onClick = { expanded = !expanded }) {
                Text(if (expanded) "Hide Advanced" else "Show Advanced")
            }
        }

        if (expanded) {
            val models = listOf("gpt-4o", "gpt-3.5-turbo", "claude-3-opus", "mistral", "deepseek-coder")
            var modelExpanded by remember { mutableStateOf(false) }

            ExposedDropdownMenuBox(
                expanded = modelExpanded,
                onExpandedChange = { modelExpanded = !modelExpanded }
            ) {
                OutlinedTextField(
                    value = settings.modelName,
                    onValueChange = {},
                    readOnly = true,
                    label = { Text("Model") },
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = modelExpanded) },
                    modifier = Modifier.fillMaxWidth()
                )
                ExposedDropdownMenu(
                    expanded = modelExpanded,
                    onDismissRequest = { modelExpanded = false }
                ) {
                    models.forEach { model ->
                        DropdownMenuItem(
                            text = { Text(model) },
                            onClick = {
                                onSettingsChange(settings.copy(modelName = model))
                                modelExpanded = false
                            }
                        )
                    }
                }
            }

            Spacer(Modifier.height(12.dp))

            LabeledSlider("Temperature", settings.temperature, 0.0f..1.5f, 0.1f) {
                onSettingsChange(settings.copy(temperature = it))
            }
            LabeledSlider("Top P", settings.topP, 0.0f..1.0f, 0.05f) {
                onSettingsChange(settings.copy(topP = it))
            }
            LabeledSlider("Max Tokens", settings.maxTokens.toFloat(), 256f..8192f, 256f) {
                onSettingsChange(settings.copy(maxTokens = it.toInt()))
            }
            LabeledSlider("Presence Penalty", settings.presencePenalty, -2.0f..2.0f, 0.1f) {
                onSettingsChange(settings.copy(presencePenalty = it))
            }
            LabeledSlider("Frequency Penalty", settings.frequencyPenalty, -2.0f..2.0f, 0.1f) {
                onSettingsChange(settings.copy(frequencyPenalty = it))
            }
        }
    }
}

@Composable
fun LabeledSlider(
    label: String,
    value: Float,
    valueRange: ClosedFloatingPointRange<Float>,
    step: Float,
    onValueChange: (Float) -> Unit
) {
    Column(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Text("$label: ${"%.2f".format(value)}")
        Slider(
            value = value,
            onValueChange = onValueChange,
            valueRange = valueRange,
            steps = ((valueRange.endInclusive - valueRange.start) / step).toInt() - 1,
            modifier = Modifier.fillMaxWidth()
        )
    }
}
